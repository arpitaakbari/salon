package com.example.rinku.beauty_salon.Drwer_Appointment;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rinku.beauty_salon.Adpater.Appointment_Book_Adapter;
import com.example.rinku.beauty_salon.Adpater.History_Appointment_Adapter;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static android.content.Context.MODE_PRIVATE;
import static com.example.rinku.beauty_salon.Activity.Appointment.customer_id;


public class History_appointment_Fragment extends Fragment {

    private APIClient apiService;
    RecyclerView history_list;
    TextView message1;
    String c_id;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_history_appointment_, container, false);

        apiService = RetroClient.getClient().create(APIClient.class);

        GetValues getValues = new GetValues((Activity) getContext());
        SharedPreferences prefs = getActivity().getSharedPreferences("myPref", MODE_PRIVATE);
        c_id = prefs.getString("CUSTOMERID", getValues.cid());

        message1 = rootView.findViewById(R.id.message1);
        history_list = rootView.findViewById(R.id.history_list);
        history_list.setLayoutManager(new LinearLayoutManager(getContext()));
        post_appointment_history();
        return rootView;
    }

    private void post_appointment_history() {
        message1.setVisibility(View.GONE);
        Call <Example> call = apiService.post_appointment_history(c_id);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                List <Datum> data = response.body().getData();
                try {
                    if (data==null){
                        message1.setVisibility(View.VISIBLE);
                        history_list.setVisibility(View.GONE);

                    }
                    else {
                        message1.setVisibility(View.GONE);
                        Log.d("DATAMAIN", "DATAonResponse:" + data);
                        History_Appointment_Adapter adapter = new History_Appointment_Adapter(data, History_appointment_Fragment.this);
                        history_list.setAdapter(adapter);
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
//                Toast.makeText(getContext(), "Try......again", Toast.LENGTH_SHORT).show();
            }
        });
    }


}
