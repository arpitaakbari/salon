package com.example.rinku.beauty_salon.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rinku.beauty_salon.Adpater.Addcart_Adapter;
import com.example.rinku.beauty_salon.Gole;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class AddCart extends AppCompatActivity {

    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private static RecyclerView recyclerView;
    TextView totalprice;
    TextView message;
    private APIClient apiService;
    String customer_id1;
    Button booknow,addmore1;
    ProgressDialog pDialog;
    List<String> ji = new ArrayList<> ();

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_add_cart);


        apiService = RetroClient.getClient ().create (APIClient.class);
        GetValues getValues = new GetValues (AddCart.this);
        SharedPreferences prefs = getSharedPreferences ("myPref", MODE_PRIVATE);
        customer_id1 = prefs.getString ("CUSTOMERID", getValues.cid ());

        Button addmore = findViewById (R.id.addmore);
       booknow = findViewById (R.id.booknow);
        addmore1=findViewById (R.id.addmore1);
        totalprice = findViewById (R.id.totalprice);
        message = findViewById (R.id.message);




        booknow.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                if (Gole.service_id != null) {
                    startActivity ((new Intent (AddCart.this, Appointment.class)));
                } else {
                    Toast.makeText (AddCart.this, "Select a services..", Toast.LENGTH_SHORT).show ();

                }
            }
        });
        addmore.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                startActivity ((new Intent (AddCart.this, Main_serviceActivity.class)));
            }
        });
        addmore1.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                startActivity ((new Intent (AddCart.this, Main_serviceActivity.class)));
            }
        });

        Toolbar toolbar = findViewById (R.id.toolbar);
        toolbar.setTitle (R.string.cart);
        setSupportActionBar (toolbar);
        if (getSupportActionBar () != null) {
            getSupportActionBar ().setDisplayHomeAsUpEnabled (true);
            getSupportActionBar ().setDisplayShowHomeEnabled (true);
        }

        recyclerView = (RecyclerView) findViewById (R.id.cartrecycle);
        recyclerView.setHasFixedSize (true);
        layoutManager = new LinearLayoutManager (this);
        recyclerView.setLayoutManager (layoutManager);
        recyclerView.setItemAnimator (new DefaultItemAnimator ());
        PostAddcart (customer_id1);
    }

    public void PostAddcart(String customer_id1) {
        pDialog = new ProgressDialog(AddCart.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        message.setVisibility (GONE);
        Call<Example> call = apiService.postAddlist (customer_id1);
        call.enqueue (new Callback<Example> () {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                List<Datum> data = response.body ().getData ();
                try{
                if (data == null) {
                    message.setVisibility (VISIBLE);
                    recyclerView.setVisibility (GONE);
                    pDialog.dismiss();
                } else {
                    for (int j = 0; j < data.size (); j++) {
                        ji.add (data.get (j).getServiceId ());
                    }
                    Gole.service_id = TextUtils.join (",", ji);
                    Log.d ("DATAMAIN", "DATAonResponse:" + Gole.joint);
                    Log.d ("DATAMAIN", "DATAonResponse:" + response);
                    pDialog.dismiss();
                    message.setVisibility (GONE);
                    addmore1.setVisibility (GONE);
                    booknow.setVisibility (GONE);
                    if (Gole.service_id == null)
                    {
                        addmore1.setVisibility (VISIBLE);
                    }
                    else {
                        booknow.setVisibility (VISIBLE);
                    }
                    totalprice.setText (String.valueOf (response.body ().getSubtotal ()));
                    adapter = new Addcart_Adapter (data, AddCart.this);
                    recyclerView.setAdapter (adapter);
                }
            }
            catch (Exception e){
                }
            }
            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.e (">> ", t.toString ());
                Toast.makeText (AddCart.this, "Connection Error", Toast.LENGTH_SHORT).show ();
                pDialog.dismiss();
            }
        });
    }


    public void Postdeletecard(String service_id) {
        message.setVisibility (GONE);
        Call<Example> call = apiService.postdeletecard (service_id, customer_id1);
        call.enqueue (new Callback<Example> () {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                List<Datum> data = response.body ().getData ();
                try{
                if (data == null) {
                    message.setVisibility (VISIBLE);
                    recyclerView.setVisibility (GONE);
//                    pDialog.dismiss();
                } else {
//                    pDialog.dismiss();
                    message.setVisibility (GONE);
                    booknow.setVisibility (GONE);
                    addmore1.setVisibility (VISIBLE);
                    Log.d ("DATARES", "DATATABLE" + response + call);
                    PostAddcart (customer_id1);
                }

            }catch (Exception e){
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Toast.makeText (AddCart.this, "Connection Error", Toast.LENGTH_SHORT).show ();
                pDialog.dismiss();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId () == android.R.id.text1) ;
        finish ();
        return super.onOptionsItemSelected (item);
    }
}
