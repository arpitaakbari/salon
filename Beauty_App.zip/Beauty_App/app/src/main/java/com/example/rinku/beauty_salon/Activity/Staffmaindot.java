package com.example.rinku.beauty_salon.Activity;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.rinku.beauty_salon.Adpater.Staffmaindot_adapter;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

public class Staffmaindot extends AppCompatActivity {

    Toolbar toolbar1;
    RecyclerView staff_rcy;
    ProgressDialog pDialog;
    private APIClient apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staffmain);

        android.support.v7.widget.Toolbar toolbar1 = findViewById (R.id.toolbar1);
        toolbar1.setTitle (R.string.Stylist);
        setSupportActionBar (toolbar1);
        if (getSupportActionBar () != null) {
            getSupportActionBar ().setDisplayHomeAsUpEnabled (true);
            getSupportActionBar ().setDisplayShowHomeEnabled (true);
        }

        apiService = RetroClient.getClient().create(APIClient.class);
        staff_rcy=findViewById(R.id.staff_rcy);
        staff_rcy.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),2);
        staff_rcy.setLayoutManager(layoutManager);
        getStafflist();
    }

    private void getStafflist() {
        try {
//            pDialog = new ProgressDialog(MainActivity.this);
//            pDialog.setMessage("Please wait...");
//            pDialog.setIndeterminate(false);
//            pDialog.setCancelable(false);
//            pDialog.show();
            Call<Example> call = apiService.Getstafflist();
            call.enqueue(new Callback<Example>() {
                @Override
                public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                    List<Datum> data = response.body().getData();
                    try {

//                        pDialog.dismiss();
                        staff_rcy.setAdapter(new Staffmaindot_adapter(Staffmaindot.this, data));
                        Log.d("DATAMAIN", "DATAonResponse:" + data);
                    } catch (Exception e) {
                    }
                }

                @Override
                public void onFailure(Call <Example> call, Throwable t) {
                    Toast.makeText(Staffmaindot.this, "Connection Error", Toast.LENGTH_SHORT).show();
//                    pDialog.dismiss();
                }
            });
        } catch (Exception ex) {

        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId () == android.R.id.text1) ;
        finish ();
        return super.onOptionsItemSelected (item);
    }
}
