package com.example.rinku.beauty_salon.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Adpater.Addcart_Adapter;
import com.example.rinku.beauty_salon.Adpater.ComformAppoinment_Adapter;
import com.example.rinku.beauty_salon.Gole;
import com.example.rinku.beauty_salon.MainActivity;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class Conform_appoinment extends AppCompatActivity {
    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    RecyclerView recyclerView;
    private APIClient apiService;
    String customer_id1;
    TextView netpay, time1, Staffname, date1;
    Button con_appo;
    ProgressDialog pDialog;

    List <String> ji = new ArrayList <>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conform_appoinment);
        apiService = RetroClient.getClient().create(APIClient.class);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.summary);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        GetValues getValues = new GetValues(Conform_appoinment.this);
        SharedPreferences prefs = getSharedPreferences("myPref", MODE_PRIVATE);
        customer_id1 = prefs.getString("CUSTOMERID", getValues.cid());

        netpay = findViewById(R.id.netpay);
        time1 = findViewById(R.id.time);
        Staffname = findViewById(R.id.Staffname);
        date1 = findViewById(R.id.date);
        con_appo = findViewById(R.id.con_appo);

        final String time = getIntent().getStringExtra("time");
        final String staff_name = getIntent().getStringExtra("staff_name");
        final String date = getIntent().getStringExtra("date");


        time1.setText(time);
        Staffname.setText(staff_name);
        date1.setText(date);

        recyclerView = (RecyclerView) findViewById(R.id.list);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        PostAddcart(customer_id1);

        con_appo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String time = time1.getText().toString();
                final String date = date1.getText().toString();
                postbookapp_insert(time, date);
            }
        });
    }

    public void postbookapp_insert(String time, String date) {
        pDialog = new ProgressDialog(Conform_appoinment.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call <Example> call = apiService.postbookapp_insert(time, Gole.staff_id, date, customer_id1, Gole.joint);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                try {

                    Log.d("DATAMAIN", "DATAonResponse:" + response);
                    Toast.makeText(Conform_appoinment.this, "book apponitment", Toast.LENGTH_SHORT).show();
                    pDialog.dismiss();
                    Intent mainIntent = new Intent(Conform_appoinment.this, MainActivity.class);
                    startActivity(mainIntent);

                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Log.e(">> ", t.toString());
                Toast.makeText(Conform_appoinment.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    public void PostAddcart(String customer_id1) {
        pDialog = new ProgressDialog(Conform_appoinment.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call <Example> call = apiService.postAddlist(customer_id1);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                List <Datum> data = response.body().getData();
                try {

                    for (int j = 0; j < data.size(); j++) {
                        ji.add(data.get(j).getServiceId());
                    }
                    Gole.joint = TextUtils.join(",", ji);
                    pDialog.dismiss();
                    Log.d("DATAMAIN", "DATAonResponse:" + Gole.joint);
//                    Toast.makeText(Conform_appoinment.this, "" + Gole.joint, Toast.LENGTH_SHORT).show();
                    netpay.setText(String.valueOf(response.body().getSubtotal()));
                    adapter = new ComformAppoinment_Adapter(data, Conform_appoinment.this);
                    recyclerView.setAdapter(adapter);
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Log.e(">> ", t.toString());
                Toast.makeText(Conform_appoinment.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return super.onOptionsItemSelected(item);
    }
}
