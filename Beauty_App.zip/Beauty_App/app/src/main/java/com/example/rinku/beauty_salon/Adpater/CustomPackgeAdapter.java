package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Activity.Package_deatil;
import com.example.rinku.beauty_salon.Activity.Packge;

import java.util.List;

public class CustomPackgeAdapter extends RecyclerView.Adapter<CustomPackgeAdapter.MyViewHolder> {
    private List<Datum> dataSet;
    Context context;


    public CustomPackgeAdapter(List<Datum> data, Packge packge) {
        dataSet = data;
        context = packge;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvname;
        TextView tvmatrial;
        TextView tvprice;
        ImageView imageViewIcon;
        CardView card_view;
        public MyViewHolder(View itemView) {
            super (itemView);
            this.tvname = (TextView) itemView.findViewById (R.id.packge_name);
            this.tvmatrial = (TextView) itemView.findViewById (R.id.packge_material);
            this.tvprice = (TextView) itemView.findViewById (R.id.packge_price);
            this.imageViewIcon = (ImageView) itemView.findViewById (R.id.packge_img);
            this.card_view=itemView.findViewById (R.id.card_view);
        }
    }

    public CustomPackgeAdapter(List<Datum> data) {
        this.dataSet = data;
    }

    @Override
    public CustomPackgeAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.packge_layout, parent, false);

        view.setOnClickListener (Packge.myOnClickListener);
        CustomPackgeAdapter.MyViewHolder myViewHolder = new CustomPackgeAdapter.MyViewHolder (view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final CustomPackgeAdapter.MyViewHolder holder, final int listPosition) {
        holder.tvname.setText( Html.fromHtml (dataSet.get (listPosition).getName ()));
        holder.tvmatrial.setText ( Html.fromHtml (dataSet.get (listPosition).getMaterils ()));
        holder.tvprice.setText (dataSet.get (listPosition).getPrice ());
        Glide.with (context).load (dataSet.get (listPosition).getImage ()).into (holder.imageViewIcon);
        final Context context = holder.imageViewIcon.getContext ();
        holder.card_view.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {

                Intent mainIntent = new Intent (context, Package_deatil.class);
                mainIntent.putExtra ("Title", dataSet.get (listPosition).getName ());
                mainIntent.putExtra ("Detail",dataSet.get (listPosition).getDescription ());
                mainIntent.putExtra ("Materils",dataSet.get (listPosition).getMaterils ());
                mainIntent.putExtra ("Price",dataSet.get (listPosition).getPrice ());
                mainIntent.putExtra ("Image", dataSet.get(listPosition).getImage ());
                context.startActivity (mainIntent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataSet.size ();
    }
}
