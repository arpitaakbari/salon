package com.example.rinku.beauty_salon.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;
import com.example.rinku.beauty_salon.Adpater.Servicetype_Adapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.example.rinku.beauty_salon.R.style.AlertDialogCustomwishlist;

public class Service_Type extends AppCompatActivity {
    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private static RecyclerView recyclerView;
    static View.OnClickListener myOnClickListener;
    private static ArrayList <Integer> removedItems;
    String customer_id;
    ProgressDialog pDialog;
    TextView message;
    private APIClient apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service__type);

        String id = getIntent().getStringExtra("id");

        GetValues getValues = new GetValues(Service_Type.this);
        SharedPreferences prefs = getSharedPreferences("myPref", MODE_PRIVATE);
        customer_id = prefs.getString("CUSTOMERID", getValues.cid());
        apiService = RetroClient.getClient().create(APIClient.class);

        message = findViewById(R.id.message);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.services_type);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        myOnClickListener = new MyOnClickListener(this);
        recyclerView = (RecyclerView) findViewById(R.id.s_type);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        Postservicetype(id);
    }

    public void PostAddcart(String service_id) {
        pDialog = new ProgressDialog(Service_Type.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        message.setVisibility(GONE);
        Call <Example> call = apiService.Postaddcart(service_id, customer_id);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                GetValues getValues = new GetValues(Service_Type.this);
                String EMAIL = getValues.mEmail();
                if (EMAIL == null) {
                    Intent intent = new Intent(Service_Type.this, Login.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                    pDialog.dismiss();
                } else {
                    pDialog.dismiss();
                    Log.d("DATARES", "DATATABLE" + response + call);
                    dailog_sin();
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Log.e(">> ", t.toString());
                Toast.makeText(Service_Type.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    private void dailog_sin() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.AlertDialogCustomCart);
        builder.setTitle("Cart");
        builder.setMessage("Add to cart");
        builder.setNegativeButton("LATER", null);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Service_Type.this, AddCart.class);
                startActivity(intent);
            }
        }).create().show();

    }

    public void PostWishlist(String service_id) {
        pDialog = new ProgressDialog(Service_Type.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call <Example> call = apiService.Postwishlistadd(service_id, customer_id);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                GetValues getValues = new GetValues(Service_Type.this);
                String EMAIL = getValues.mEmail();
                if (EMAIL == null) {
                    Intent intent = new Intent(Service_Type.this, Login.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                    pDialog.dismiss();
                } else {
                    pDialog.dismiss();
                    Log.d("DATARES", "DATATABLE" + response + call);
                    dailog_sin1();
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Toast.makeText(Service_Type.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    private void dailog_sin1() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.AlertDialogCustomwishlist);
        builder.setTitle("Wish list");
        builder.setMessage("Add to wish list");
        builder.setNegativeButton("LATER", null);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Service_Type.this, Wishlist.class);
                startActivity(intent);
            }
        }).create().show();
    }

    private void Postservicetype(String id) {
        pDialog = new ProgressDialog(Service_Type.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        message.setVisibility(GONE);
        Call <Example> call = apiService.Postservicetype(id);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                List <Datum> data = response.body().getData();
                try {

                    if (data == null) {
                        message.setVisibility(VISIBLE);
                        recyclerView.setVisibility(GONE);
                        pDialog.dismiss();
                    } else {
                        pDialog.dismiss();
                        Log.d("DATAMAIN", "DATAonResponse:" + data);
                        message.setVisibility(GONE);
                        adapter = new Servicetype_Adapter(data, Service_Type.this);
                        recyclerView.setAdapter(adapter);
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Log.e(">> ", t.toString());
                Toast.makeText(Service_Type.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return true;
    }

    public static class MyOnClickListener implements View.OnClickListener {
        private final Context context;

        public MyOnClickListener(Service_Type context) {
            this.context = context;
        }

        @Override
        public void onClick(View v) {
        }
    }
}
