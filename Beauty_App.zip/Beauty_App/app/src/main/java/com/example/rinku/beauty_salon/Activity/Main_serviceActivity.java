package com.example.rinku.beauty_salon.Activity;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.rinku.beauty_salon.Adpater.MainService_categoryAdapter;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static android.view.View.GONE;

public class Main_serviceActivity extends AppCompatActivity {

    Toolbar toolbar1;
    RecyclerView rcy_services;
    ProgressDialog pDialog;
    private APIClient apiService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_service);

        android.support.v7.widget.Toolbar toolbar1 = findViewById (R.id.toolbar1);
        toolbar1.setTitle (R.string.services_master);
        setSupportActionBar (toolbar1);
        if (getSupportActionBar () != null) {
            getSupportActionBar ().setDisplayHomeAsUpEnabled (true);
            getSupportActionBar ().setDisplayShowHomeEnabled (true);
        }


        apiService = RetroClient.getClient().create(APIClient.class);
        rcy_services=findViewById(R.id.rcy_services);
        rcy_services.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),2);
        rcy_services.setLayoutManager(layoutManager);
        getservice_categorylist();
    }

    private void getservice_categorylist() {
        pDialog = new ProgressDialog(Main_serviceActivity.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
//        message.setVisibility(View.GONE);
        try {
            Call<Example> call = apiService.Getservice_categorylist();
            call.enqueue(new Callback<Example>() {
                @Override
                public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                    List<Datum> data = response.body().getData();
                    if (data == null) {
//                        message.setVisibility(VISIBLE);
                        rcy_services.setVisibility(GONE);
                        pDialog.dismiss();
                    } else {
                        pDialog.dismiss();
                        Log.d("DATAMAIN", "DATAonResponse:" + data);
                        rcy_services.setAdapter(new MainService_categoryAdapter(Main_serviceActivity.this, data));
                    }

                }

                @Override
                public void onFailure(Call <Example> call, Throwable t) {
                    Toast.makeText(Main_serviceActivity.this, "Connection Error", Toast.LENGTH_SHORT).show();
                    pDialog.dismiss();
                }
            });
        } catch (Exception ex) {
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId () == android.R.id.text1) ;
        finish ();
        return super.onOptionsItemSelected (item);
    }
}
