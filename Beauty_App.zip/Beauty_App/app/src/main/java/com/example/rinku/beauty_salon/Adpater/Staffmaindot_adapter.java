package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Activity.Staffdetails;
import com.example.rinku.beauty_salon.Activity.Staffmaindot;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;

public class Staffmaindot_adapter extends RecyclerView.Adapter <Staffmaindot_adapter.MyViewHolder> {
    private List <Datum> dataSet;
    Context context;

    public Staffmaindot_adapter(Staffmaindot staffmain, List <Datum> data) {
        dataSet = data;
        context = staffmain;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemview = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.staffmaindot_layout, null);
        return new Staffmaindot_adapter.MyViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int listPosition) {
        holder.staff_name.setText (dataSet.get (listPosition).getName ());
        Glide.with (context).load (dataSet.get (listPosition).getImage ()).into (holder.staff_image);
        holder.staff_card.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context,Staffdetails.class);
                intent.putExtra("id",dataSet.get(listPosition).getId());
                intent.putExtra("staffname",dataSet.get(listPosition).getName());
                intent.putExtra("staffimage",dataSet.get(listPosition).getImage());
                intent.putExtra("gender",dataSet.get(listPosition).getGender());
                intent.putExtra("email",dataSet.get(listPosition).getEmail());
                intent.putExtra("starttime",dataSet.get(listPosition).getStarttime());
                intent.putExtra("endtime",dataSet.get(listPosition).getEndtime());
                intent.putExtra("skillname",dataSet.get(listPosition).getSkillName());
                context.startActivity (intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView staff_name;
        ImageView staff_image;
        CardView staff_card;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            this.staff_card = (CardView) itemView.findViewById (R.id.staff_card);
            this.staff_name = (TextView) itemView.findViewById (R.id.staff_name);
            this.staff_image = (ImageView) itemView.findViewById (R.id.staff_image);
        }
    }
}
