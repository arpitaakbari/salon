package com.example.rinku.beauty_salon.Activity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

import com.example.rinku.beauty_salon.Adpater.Staffmaster_adapter;
import com.example.rinku.beauty_salon.Adpater.Stafftime_adapter;
import com.example.rinku.beauty_salon.Gole;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;


public class Appointment extends AppCompatActivity {
    private Button weekCalendar;
    RecyclerView staff_rcy, time_rcy;
    private APIClient apiService;
    public static String date2,date3, customer_id;
    ProgressDialog pDialog;
    DatePickerDialog datePickerDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        apiService = RetroClient.getClient().create(APIClient.class);
        GetValues getValues = new GetValues(Appointment.this);
        SharedPreferences prefs = getSharedPreferences("myPref", MODE_PRIVATE);
        customer_id = prefs.getString("CUSTOMERID", getValues.cid());
        final String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.Appoinment);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        Button btnbookappoinment = findViewById(R.id.btnbookappoinment);
        btnbookappoinment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Gole.time != null && Gole.staff_name1 != null && date2 != null) {
                    Intent mainIntent = new Intent(Appointment.this, Conform_appoinment.class);
                    mainIntent.putExtra("time", Gole.time);
                    mainIntent.putExtra("staff_name", Gole.staff_name1);
                    mainIntent.putExtra("date", date2);
                    startActivity(mainIntent);
                } else {
                    Toast.makeText(Appointment.this, "Select All Values ", Toast.LENGTH_SHORT).show();

                }
            }
        });


        weekCalendar = findViewById(R.id.weekCalendar);
        weekCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                final int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                datePickerDialog = new DatePickerDialog(Appointment.this, R.style.DialogTheme, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int y, int m, int d) {


                        int month = m + 1;
                        String formattedMonth = "" + month;
                        String formattedDayOfMonth = "" + d;
                        String formattedYear = String.valueOf(year);

                        if (month < 10) {

                            formattedMonth = "0" + month;
                        }
                        if (d < 10) {

                            formattedDayOfMonth = "0" + d;
                        }

                        date2 = formattedYear + "-" + formattedMonth + "-" + formattedDayOfMonth;
//                        date3 = formattedDayOfMonth + "/" + formattedMonth + "/" + formattedYear;

                        if (date.equals(date2)) {
                            pDialog = new ProgressDialog(Appointment.this);
                            pDialog.setMessage("Please wait...");
                            pDialog.setIndeterminate(false);
                            pDialog.setCancelable(false);
                            pDialog.show();
                            Gettimeslot();
                            pDialog.dismiss();

                        } else if (date != date2) {
                            pDialog.dismiss();
                            Gettimeslot_list();
                        } else {
                            pDialog.dismiss();
                            Gettimeslot();
                        }

                    }
                }, year, month, dayOfMonth);

                datePickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis() - 1000);
                datePickerDialog.show();
            }
        });
        staff_rcy = findViewById(R.id.staff_rcy);
        staff_rcy.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        getStafflist();

        time_rcy = findViewById(R.id.time_rcy);
        time_rcy.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        Gettimeslot();
    }

    public void postchkbooking(String time) {
        Call<Example> call = apiService.postchkbooking(time, date2, Gole.staff_name1, Gole.s_id);
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                Log.d("DATARES", "DATATABLE" + response + call);
                try {
                    if (response.body().getSuccess() == 0) {
                        Toast.makeText(Appointment.this, "Oops!! booking Not found.." + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        pDialog.dismiss();
                    } else {
                        pDialog.dismiss();
                        Toast.makeText(Appointment.this, "already booking ,try to anthor slot." + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.e(">> ", t.toString());
                Toast.makeText(Appointment.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    private void Gettimeslot_list() {
        Call<Example> call = apiService.Gettimeslot_list();
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                List<Datum> data = response.body().getData();
                try {
                    Log.d("DATAMAIN", "DATAonResponse:" + data);
                    Stafftime_adapter adapter = new Stafftime_adapter(data, Appointment.this);
                    time_rcy.setAdapter(adapter);
                    pDialog.dismiss();
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Toast.makeText(Appointment.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    private void Gettimeslot() {
        Call<Example> call = apiService.Gettimeslotlist();
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                List<Datum> data = response.body().getData();
                try {

                    Log.d("DATAMAIN", "DATAonResponse:" + data);
                    Stafftime_adapter adapter = new Stafftime_adapter(data, Appointment.this);
                    time_rcy.setAdapter(adapter);
                    pDialog.dismiss();
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Toast.makeText(Appointment.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }


    private void getStafflist() {
        try {
            pDialog = new ProgressDialog(Appointment.this);
            pDialog.setMessage("Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
            Call<Example> call = apiService.Getstafflist();
            call.enqueue(new Callback<Example>() {
                @Override
                public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                    List<Datum> data = response.body().getData();
                    try {

                        pDialog.dismiss();
                        staff_rcy.setAdapter(new Staffmaster_adapter(Appointment.this, data));
                        Log.d("DATAMAIN", "DATAonResponse:" + data);
                    } catch (Exception e) {
                    }
                }

                @Override
                public void onFailure(Call<Example> call, Throwable t) {
                    Toast.makeText(Appointment.this, "Connection Error", Toast.LENGTH_SHORT).show();
                    pDialog.dismiss();
                }
            });
        } catch (Exception ex) {
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return super.onOptionsItemSelected(item);
    }
}
