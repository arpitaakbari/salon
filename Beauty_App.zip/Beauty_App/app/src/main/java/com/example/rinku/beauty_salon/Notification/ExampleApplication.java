package com.example.rinku.beauty_salon.Notification;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

import com.example.rinku.beauty_salon.Splash_screen;
import com.onesignal.OSNotificationAction;
import com.onesignal.OSNotificationOpenResult;
import com.onesignal.OSNotification;
import com.onesignal.OneSignal;

import org.json.JSONObject;

public  class ExampleApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate ();
        OneSignal.startInit (this)
                .setNotificationReceivedHandler (new ExampleNotificationReceivedHandler ())
                .setNotificationOpenedHandler (new ExampleNotificationOpenedHandler ())
                .inFocusDisplaying (OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled (true)
                .init ();
    }

    private class ExampleNotificationReceivedHandler implements OneSignal.NotificationReceivedHandler {
        @Override
        public void notificationReceived(OSNotification notification) {

                JSONObject data = notification.payload.additionalData;
                String notificationID = notification.payload.notificationID;
                String title = notification.payload.title;
                String body = notification.payload.body;
                String smallIcon = notification.payload.smallIcon;
                String largeIcon = notification.payload.largeIcon;
                String bigPicture = notification.payload.bigPicture;
                String smallIconAccentColor = notification.payload.smallIconAccentColor;
                String sound = notification.payload.sound;
                String ledColor = notification.payload.ledColor;
                int lockScreenVisibility = notification.payload.lockScreenVisibility;
                String groupKey = notification.payload.groupKey;
                String groupMessage = notification.payload.groupMessage;
                String fromProjectNumber = notification.payload.fromProjectNumber;
                String rawPayload = notification.payload.rawPayload;
                String customKey;

        }
    }


    private class ExampleNotificationOpenedHandler implements OneSignal.NotificationOpenedHandler {
        // This fires when a notification is opened by tapping on it.
        @Override
        public void notificationOpened(OSNotificationOpenResult result) {


                OSNotificationAction.ActionType actionType = result.action.type;
                JSONObject data = result.notification.payload.additionalData;
                String launchUrl = result.notification.payload.launchURL; // update docs launchUrl

                String customKey;
                String openURL = null;
                Object activityToLaunch = Splash_screen.class;



            if (actionType == OSNotificationAction.ActionType.ActionTaken) {
                Log.i("OneSignalExample", "Button pressed with id: " + result.action.actionID);

                if (result.action.actionID.equals("1")) {
                    Log.i("OneSignalExample", "button id called: " + result.action.actionID);
                    activityToLaunch = notification.class;
                } else
                    activityToLaunch = Splash_screen.class;
                    Log.i("OneSignalExample", "button id called: " + result.action.actionID);
            }
            Intent intent = new Intent(getApplicationContext(), (Class<?>) activityToLaunch);
            intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK);
           startActivity(intent);
        }
    }
}
