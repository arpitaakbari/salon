package com.example.rinku.beauty_salon.Adpater;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.rinku.beauty_salon.Drwer_Appointment.Book_appointment_Fragment;
import com.example.rinku.beauty_salon.Drwer_Appointment.History_appointment_Fragment;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;

public class History_Appointment_Adapter extends RecyclerView.Adapter<History_Appointment_Adapter.MyViewHolder> {
    private List<Datum> dataSet;
    History_appointment_Fragment contxt1;

    public History_Appointment_Adapter(List<Datum> data, History_appointment_Fragment history_appointment_fragment) {
        dataSet=data;
        contxt1=history_appointment_fragment;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView s_price;
        TextView txt_time;
        TextView txt_date;
        TextView txt_services;
        Button btn_appointment_delete;

        public MyViewHolder(View itemView) {
            super (itemView);
            this.s_price = itemView.findViewById (R.id.s_price);
            this.txt_time = itemView.findViewById (R.id.txt_time);
            this.txt_date = itemView.findViewById (R.id.txt_date);
            this.txt_services=itemView.findViewById (R.id.txt_services);
            this.btn_appointment_delete=itemView.findViewById (R.id.btn_appointment_delete);
        }
    }

    @Override
    public History_Appointment_Adapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.appointment_histroy_layout, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder (view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final History_Appointment_Adapter.MyViewHolder holder, final int listPosition) {

        holder.s_price.setText (dataSet.get (listPosition).getPrice ());
        holder.txt_time.setText (dataSet.get (listPosition).getTime ());
        holder.txt_date.setText (dataSet.get (listPosition).getDate ());
        holder.txt_services.setText (dataSet.get (listPosition).getServiceName ());

    }


    @Override
    public int getItemCount() {
        return dataSet.size ();
    }
}
