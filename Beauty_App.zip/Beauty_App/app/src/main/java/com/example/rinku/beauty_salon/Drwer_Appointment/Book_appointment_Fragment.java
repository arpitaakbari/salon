package com.example.rinku.beauty_salon.Drwer_Appointment;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rinku.beauty_salon.Activity.AddCart;
import com.example.rinku.beauty_salon.Activity.Service_Type;
import com.example.rinku.beauty_salon.Adpater.Appointment_Book_Adapter;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static android.content.Context.MODE_PRIVATE;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;


public class Book_appointment_Fragment extends Fragment {
    private APIClient apiService;
    RecyclerView list_app;
    String c_id;
    TextView message1;
    ProgressDialog pDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_book_appointment_, container, false);

        apiService = RetroClient.getClient().create(APIClient.class);
        GetValues getValues = new GetValues((Activity) getContext());
        SharedPreferences prefs = getActivity().getSharedPreferences("myPref", MODE_PRIVATE);
        c_id = prefs.getString("CUSTOMERID", getValues.cid());
        message1 = rootView.findViewById(R.id.message1);
        list_app = rootView.findViewById(R.id.list_app);
        list_app.setLayoutManager(new LinearLayoutManager(getContext()));
        postappointment_list(c_id);
        return rootView;
    }

    private void postappointment_list(String c_id) {
        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        message1.setVisibility(GONE);
        Call <Example> call = apiService.appointment_history(c_id);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                List <Datum> data = response.body().getData();
                try {
                    if (data == null) {
                        message1.setVisibility(VISIBLE);
                        list_app.setVisibility(GONE);
                        pDialog.dismiss();
                    } else {
                        pDialog.dismiss();
                        Log.d("DATAMAIN", "DATAonResponse:" + data);
                        message1.setVisibility(GONE);
                        Appointment_Book_Adapter adapter = new Appointment_Book_Adapter(data, Book_appointment_Fragment.this);
                        list_app.setAdapter(adapter);
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Toast.makeText(getContext(), "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    public void Postdelete_appointment(String service_id) {
        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        message1.setVisibility(GONE);
        Call <Example> call = apiService.delete_appointment_history(c_id, service_id);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                List <Datum> data = response.body().getData();
                try {
                    if (data == null) {
                        message1.setVisibility(VISIBLE);
                        list_app.setVisibility(GONE);
                        pDialog.dismiss();
                    } else {
                        pDialog.dismiss();
                        message1.setVisibility(GONE);
                        Log.d("DATARES", "DATATABLE" + response + call);
                        Toast.makeText(getContext(), "Delete Serive", Toast.LENGTH_SHORT).show();
                        postappointment_list(c_id);
//                        dailog_sin();
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Toast.makeText(getContext(), "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

//    private void dailog_sin() {
//        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getContext(), R.style.AlertDialogCustomCart);
//        builder.setTitle("Delete");
//        builder.setMessage("Are you sure????");
//        builder.setNegativeButton("No", null);
//        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                Intent intent = new Intent(getContext(), AddCart.class);
//                startActivity(intent);
//            }
//        }).create().show();
//    }
}
