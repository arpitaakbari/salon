package com.example.rinku.beauty_salon.Blog;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.rinku.beauty_salon.R;

public class howtouse  extends Fragment {
    TextView blog_howtouse;
    String bloghowtouse;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        Bundle b = getActivity().getIntent().getExtras();
        bloghowtouse = b.getString("used");

        View view= inflater.inflate(R.layout.howtouse, container, false);

        blog_howtouse=view.findViewById(R.id.blog_howtouse);
        blog_howtouse.setText(Html.fromHtml(bloghowtouse));
        return view;
    }
}
