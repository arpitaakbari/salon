package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Activity.Appointment;
import com.example.rinku.beauty_salon.Activity.Offersmain;
import com.example.rinku.beauty_salon.MainActivity;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;

public class Custom_Offer_Adapter extends RecyclerView.Adapter <Custom_Offer_Adapter.ViewHolder> {

    List <Datum> dataset;
    Context context;


    public Custom_Offer_Adapter(MainActivity mainActivity, List <Datum> data) {
        dataset = data;
        context = mainActivity;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView images;
        private TextView title;
        private TextView title2;
        CardView layer;

        public ViewHolder(View itemView) {
            super(itemView);
            images = (ImageView) itemView.findViewById(R.id.image);
            title = (TextView) itemView.findViewById(R.id.title);
            title2 = (TextView) itemView.findViewById(R.id.title2);
            layer = (CardView) itemView.findViewById(R.id.layer);
        }

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View itemview = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.viewpager, null);
        return new ViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {
        viewHolder.title.setText(dataset.get(i).getServiceName());
        viewHolder.title2.setText(dataset.get(i).getTitle());
        Glide.with(context).load(dataset.get(i).getImage()).into(viewHolder.images);

        viewHolder.layer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(context, Offersmain.class);
                mainIntent.putExtra("offerstitle", dataset.get(i).getServiceName());
                mainIntent.putExtra("offersdes",dataset.get(i).getDescription());
                mainIntent.putExtra("offersimg",dataset.get(i).getImage());
                context.startActivity(mainIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }

}
