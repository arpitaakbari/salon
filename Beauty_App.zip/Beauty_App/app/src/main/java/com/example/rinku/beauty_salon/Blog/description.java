package com.example.rinku.beauty_salon.Blog;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.GetValues;

import static android.content.Context.MODE_PRIVATE;

public class description extends Fragment {
    TextView blog_detail;
    String detail;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        Bundle b = getActivity().getIntent().getExtras();
        detail = b.getString("detail");


        View rootView = inflater.inflate(R.layout.description, container, false);
        blog_detail = rootView.findViewById(R.id.blog_detail);

        blog_detail.setText(Html.fromHtml(detail));
        return rootView;

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
