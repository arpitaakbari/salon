package com.example.rinku.beauty_salon.Notification;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rinku.beauty_salon.Adpater.Notifiction_Adapter;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class notification extends AppCompatActivity {
    RecyclerView recyclerView;
    private static RecyclerView.Adapter adapter;
    private APIClient apiService;
    TextView mssage;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_notification);
        apiService = RetroClient.getClient ().create (APIClient.class);
        Toolbar toolbar = findViewById (R.id.toolbar);
        mssage = findViewById (R.id.mssage);
        toolbar.setTitle (R.string.notification);
        setSupportActionBar (toolbar);
        if (getSupportActionBar () != null) {
            getSupportActionBar ().setDisplayHomeAsUpEnabled (true);
            getSupportActionBar ().setDisplayShowHomeEnabled (true);
        }
        recyclerView = (RecyclerView) findViewById (R.id.noti_recycle);
        recyclerView.setHasFixedSize (true);
        layoutManager = new LinearLayoutManager (this);
        recyclerView.setLayoutManager (layoutManager);
        recyclerView.setItemAnimator (new DefaultItemAnimator ());
        notification_list ();
    }

    private void notification_list() {
        mssage.setVisibility (GONE);
        Call<Example> call = apiService.getnoti_list ();
        call.enqueue (new Callback<Example> () {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                List<Datum> data = response.body ().getData ();
                if (data == null) {
                    mssage.setVisibility (VISIBLE);
                    recyclerView.setVisibility (GONE);
                } else {
                    Log.d ("DATAMAIN", "DATAonResponse:" + data);
                    mssage.setVisibility (GONE);
                    adapter = new Notifiction_Adapter (data, notification.this);
                    recyclerView.setAdapter (adapter);
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.e (">> ", t.toString ());
                Toast.makeText (notification.this, "Try..again", Toast.LENGTH_SHORT).show ();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId () == android.R.id.text1) ;
        finish ();
        return super.onOptionsItemSelected (item);
    }

}
