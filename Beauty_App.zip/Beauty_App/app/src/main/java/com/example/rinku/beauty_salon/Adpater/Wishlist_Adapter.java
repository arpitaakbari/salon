package com.example.rinku.beauty_salon.Adpater;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Activity.Wishlist;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;
public class Wishlist_Adapter extends RecyclerView.Adapter<Wishlist_Adapter.MyViewHolder> {
    Wishlist context;
    private List<Datum> dataSet;

    public Wishlist_Adapter(List<Datum> data, Wishlist wishlist) {
        dataSet = data;
        context = wishlist;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView s_name;
        TextView s_price;
        ImageView s_img;
        ImageButton delete;
        public MyViewHolder(View itemView) {
            super (itemView);
            this.s_name = (TextView) itemView.findViewById (R.id.s_name);
            this.s_price = (TextView) itemView.findViewById (R.id.s_price);
            this.s_img = (ImageView) itemView.findViewById (R.id.s_img);
            this.delete = (ImageButton) itemView.findViewById (R.id.delete);
        }
    }

    @NonNull
    @Override
    public Wishlist_Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from (viewGroup.getContext ()).inflate (R.layout.cart_layout, viewGroup, false);
        MyViewHolder myViewHolder = new MyViewHolder (view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Wishlist_Adapter.MyViewHolder myViewHolder, final int i) {
        myViewHolder.s_name.setText (dataSet.get (i).getServiceName ());
        Glide.with (context).load (dataSet.get (i).getImage ()).into (myViewHolder.s_img);
        myViewHolder.s_price.setText (dataSet.get (i).getPrice ());
        myViewHolder.delete.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                context.Postdeletewishlist(dataSet.get(i).getServiceId ());
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }
}
