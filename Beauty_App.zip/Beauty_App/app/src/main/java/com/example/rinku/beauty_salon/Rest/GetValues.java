package com.example.rinku.beauty_salon.Rest;

import android.app.Activity;
import android.content.SharedPreferences;

import static android.content.Context.MODE_PRIVATE;

public class GetValues {
    Activity activity;

    public GetValues(Activity activity) {

        this.activity = activity;
    }

    public String mEmail() {
        SharedPreferences prefs = activity.getSharedPreferences("myPref", MODE_PRIVATE);
        return prefs.getString("EMAIL", null);
    }

    public String mName() {
        SharedPreferences prefs = activity.getSharedPreferences("myPref", MODE_PRIVATE);
        return prefs.getString("NAME", null);
    }

    public String mGender() {
        SharedPreferences prefs = activity.getSharedPreferences("myPref", MODE_PRIVATE);
        return prefs.getString("GENDER", null);
    }

    public String mPhono() {
        SharedPreferences prefs = activity.getSharedPreferences("myPref", MODE_PRIVATE);
        return prefs.getString("PHONO", null);
    }

    public String cid() {
        SharedPreferences prefs = activity.getSharedPreferences("myPref", MODE_PRIVATE);
        return prefs.getString("CUSTOMERID", null);
    }

    public String blogdetails() {
        SharedPreferences prefs = activity.getSharedPreferences("myPref", MODE_PRIVATE);
        return prefs.getString("detail", null);
    }

}
