package com.example.rinku.beauty_salon.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.R;

public class Offersmain extends AppCompatActivity {

    Toolbar toolbar;
    ImageView offers_img;
    TextView offers_title, offers_des;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offersmain);

        offers_img = findViewById(R.id.offers_img);
        offers_des = findViewById(R.id.offers_des);
        offers_title = findViewById(R.id.offers_title);

        String offersimg = getIntent().getStringExtra("offersimg");
        String offerstitle = getIntent().getStringExtra("offerstitle");
        String offersdes = getIntent().getStringExtra("offersdes");

        Glide.with(this).load(offersimg).into(offers_img);
        offers_title.setText(offerstitle);
        offers_des.setText(Html.fromHtml(offersdes));

        android.support.v7.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.offer);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return super.onOptionsItemSelected(item);
    }
}
