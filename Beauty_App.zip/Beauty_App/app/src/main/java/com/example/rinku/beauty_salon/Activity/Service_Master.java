package com.example.rinku.beauty_salon.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.RetroClient;
import com.example.rinku.beauty_salon.Adpater.ServicesMaster_Adapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class Service_Master extends AppCompatActivity {

    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private static RecyclerView recyclerView;
    static View.OnClickListener myOnClickListener;
    private static ArrayList <Integer> removedItems;
    ProgressDialog pDialog;
    TextView message;

    ///******************************

    private APIClient apiService;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_master);

        apiService = RetroClient.getClient().create(APIClient.class);

        ImageView img_service = findViewById(R.id.img_service);
        String image = getIntent().getStringExtra("image");
        String id = getIntent().getStringExtra("id");
        message = findViewById(R.id.message);

        Glide.with(this).load(image).into(img_service);

        CollapsingToolbarLayout collapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsingToolbarLayout);
        collapsingToolbarLayout.setExpandedTitleColor(Color.WHITE);
        collapsingToolbarLayout.setCollapsedTitleTextColor(Color.WHITE);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.services_master);
        toolbar.setTitleTextColor(R.color.textcolor);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        myOnClickListener = new Service_Master.MyOnClickListener(this);
        recyclerView = (RecyclerView) findViewById(R.id.sevices);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        Postservicemaster(id);
    }

    private void Postservicemaster(String id) {
        pDialog = new ProgressDialog(Service_Master.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        message.setVisibility(GONE);
        Call <Example> call = apiService.Postlist(id);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                List <Datum> data = response.body().getData();
                try {

                    if (data == null) {
                        message.setVisibility(VISIBLE);
                        recyclerView.setVisibility(GONE);
                        pDialog.dismiss();
                    } else {
                        pDialog.dismiss();
                        Log.d("DATAMAIN", "DATAonResponse:" + data);
                        adapter = new ServicesMaster_Adapter(data, Service_Master.this);
                        recyclerView.setAdapter(adapter);
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Log.d("FAIL", t.getMessage());
                Toast.makeText(Service_Master.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        if (item.getItemId() == R.id.add_item) {
            if (removedItems.size() != 0) {
            } else {
                Toast.makeText(this, "Nothing to add", Toast.LENGTH_SHORT).show();
            }
        }
        return true;
    }

    public static class MyOnClickListener implements View.OnClickListener {
        private final Context context;

        public MyOnClickListener(Service_Master context) {
            this.context = context;
        }

        @Override
        public void onClick(View v) {
        }
    }
}

