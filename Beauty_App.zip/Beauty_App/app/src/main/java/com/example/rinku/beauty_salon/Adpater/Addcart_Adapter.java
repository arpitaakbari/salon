package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Activity.AddCart;
import com.example.rinku.beauty_salon.Activity.Conform_appoinment;
import com.example.rinku.beauty_salon.Gole;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.ArrayList;
import java.util.List;

public class Addcart_Adapter extends RecyclerView.Adapter<Addcart_Adapter.MyViewHolder> {
    private List<Datum> dataSet;
    AddCart context;
    Conform_appoinment context1;
    private String total;

    public Addcart_Adapter(List<Datum> data, AddCart addCart) {
        dataSet = data;
        context = addCart;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView s_name;
        TextView s_price;
        ImageView s_img;
        ImageButton delete;
        CardView card_view;

        public MyViewHolder(View itemView) {
            super (itemView);
            this.s_name = (TextView) itemView.findViewById (R.id.s_name);
            this.s_price = (TextView) itemView.findViewById (R.id.s_price);
            this.s_img = (ImageView) itemView.findViewById (R.id.s_img);
            this.card_view = (CardView) itemView.findViewById (R.id.card_view);
            this.delete = (ImageButton) itemView.findViewById (R.id.delete);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from (viewGroup.getContext ()).inflate (R.layout.cart_layout, viewGroup, false);
        MyViewHolder myViewHolder = new MyViewHolder (view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, final int i) {
        myViewHolder.s_name.setText (dataSet.get (i).getServiceName ());
        myViewHolder.s_price.setText (dataSet.get (i).getPrice ());
        Gole.s_id=dataSet.get(i).getServiceId();
        Glide.with (context).load (dataSet.get (i).getImage ()).into (myViewHolder.s_img);
        myViewHolder.delete.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                context.Postdeletecard(dataSet.get(i).getServiceId ());
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataSet.size ();
    }
}
