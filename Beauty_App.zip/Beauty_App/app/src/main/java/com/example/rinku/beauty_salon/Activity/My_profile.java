package com.example.rinku.beauty_salon.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.GetValues;

public class My_profile extends AppCompatActivity {

    ImageButton edit_profile;
    android.support.v7.widget.Toolbar profiletoolbar;
    TextView textView_nm1, textView_mail1, textView_con1, textView_gen1;
    String email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_my_profile_main);

        textView_nm1 = findViewById (R.id.textView_nm1);
        textView_mail1 = findViewById (R.id.textView_mail1);
        textView_con1 = findViewById (R.id.textView_con1);
        textView_gen1 = findViewById (R.id.textView_gen1);
        edit_profile = findViewById (R.id.edit_profile);

        android.support.v7.widget.Toolbar profiletoolbar = findViewById(R.id.profiletoolbar);
        setTitle(R.string.myprofile);
        setSupportActionBar(profiletoolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

        }


        edit_profile.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent (My_profile.this, Edit_profile.class);
                startActivity (intent);
            }
        });

        GetValues getValues = new GetValues (My_profile.this);
        textView_nm1.setText (getValues.mName ());
        textView_mail1.setText (getValues.mEmail ());
        textView_con1.setText (getValues.mPhono ());
        textView_gen1.setText (getValues.mGender ());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId () == android.R.id.text1) ;
        finish ();
        return super.onOptionsItemSelected (item);
    }
}

