package com.example.rinku.beauty_salon.Blog;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.support.design.widget.TabLayout;
import android.support.v4.content.FileProvider;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.rinku.beauty_salon.Gole;
import com.example.rinku.beauty_salon.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Blog_detail extends AppCompatActivity implements TabLayout.OnTabSelectedListener {

    ImageButton blog_share;
    ImageView blog_imgs;
    TextView blog_title1;
    Context context = null;
    String urlForShareImage;
    Uri uri;
    TabLayout tabLayout;
    ViewPager viewPager;
    ViewPagerAdapter viewPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_blog_detail);

        init ();

        blog_share = findViewById (R.id.blog_share);
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                Method method = null;
                try {
                    method = StrictMode.class.getMethod ("ss");
                } catch (NoSuchMethodException e) {
                    e.printStackTrace ();
                }
                try {
                    method.invoke (null);
                } catch (IllegalAccessException e) {
                    e.printStackTrace ();
                } catch (InvocationTargetException e) {
                    e.printStackTrace ();
                }
            } catch (Exception e) {
            }
        }

        blog_title1 = findViewById (R.id.blog_title1);
        blog_imgs = findViewById (R.id.blog_imgs);

        Toolbar toolbar = findViewById (R.id.toolbar);
        toolbar.setTitle ("");
        setSupportActionBar (toolbar);
        if (getSupportActionBar () != null) {
            getSupportActionBar ().setDisplayHomeAsUpEnabled (true);
            getSupportActionBar ().setDisplayShowHomeEnabled (true);
        }

        TextView blog_title = findViewById (R.id.blog_title);

        final String title = getIntent ().getStringExtra ("title");
        final String detail = getIntent ().getStringExtra ("detail");
        final String image = getIntent ().getStringExtra ("image");
        Glide.with (this).load (image).diskCacheStrategy (DiskCacheStrategy.ALL).into (blog_imgs);
        blog_title.setText (Html.fromHtml (title));
        blog_title1.setText (Html.fromHtml (title));

        blog_share.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                saveImage ();
            }

            private void saveImage() {

                blog_imgs.buildDrawingCache ();
                blog_imgs.setDrawingCacheEnabled (true);
                Bitmap bmap = blog_imgs.getDrawingCache ();
                OutputStream output;
                String ss = new SimpleDateFormat ("yyyyMMdd_HHmmss").format (new Date ());
                String path = String.valueOf (Environment.getExternalStoragePublicDirectory (Gole.Edit_Folder_name + "/" + ss + ".jpg"));
                urlForShareImage = path;
                Log.d ("DATAMAIN001", "DATAMAIN001" + path);
                File file = new File (path);
                try {
                    output = new FileOutputStream (file);
                    bmap.compress (Bitmap.CompressFormat.JPEG, 100, output);
                    output.close ();
                } catch (Exception e) {
                    e.printStackTrace ();
                }
                uri = FileProvider.getUriForFile (Blog_detail.this, getApplicationContext ().getPackageName () + ".provider", file);
                Intent sharingIntent = new Intent ("android.intent.action.SEND");
                sharingIntent.setType ("image/*");
                sharingIntent.putExtra ("android.intent.extra.TEXT", "https://play.google.com/store/apps/details?id=" + getPackageName ());
                sharingIntent.putExtra ("android.intent.extra.STREAM", uri);
                startActivity (Intent.createChooser (sharingIntent, "Share Image using"));
            }
        });

    }

    private void init() {
        tabLayout = findViewById (R.id.tabLayout);
        tabLayout.addTab (tabLayout.newTab ().setText ("DESCRIPTION"));
        tabLayout.addTab (tabLayout.newTab ().setText ("HOW TO USE"));
        tabLayout.addTab (tabLayout.newTab ().setText ("INGREDIENTS"));
        tabLayout.setTabGravity (TabLayout.GRAVITY_FILL);
        viewPager = findViewById (R.id.pager);
        viewPagerAdapter = new ViewPagerAdapter (getSupportFragmentManager (), tabLayout.getTabCount ());
        viewPager.setAdapter (viewPagerAdapter);
        viewPager.addOnPageChangeListener (new TabLayout.TabLayoutOnPageChangeListener (tabLayout));
        tabLayout.setOnTabSelectedListener (this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId () == android.R.id.text1) ;
        finish ();
        return super.onOptionsItemSelected (item);
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        viewPager.setCurrentItem (tab.getPosition ());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {
    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {
    }
}