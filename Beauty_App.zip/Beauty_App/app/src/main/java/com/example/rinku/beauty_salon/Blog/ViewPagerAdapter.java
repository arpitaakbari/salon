package com.example.rinku.beauty_salon.Blog;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {

    int tabCount;

    public ViewPagerAdapter(FragmentManager fm,int tabCount) {
        super(fm);
        this.tabCount= tabCount;
    }

    @Override
    public Fragment getItem(int i) {
        switch (i) {
            case 0:
                description description = new description();
                return description;
            case 1:
                howtouse howtouse = new howtouse();
                return howtouse;
            case 2:
                ingredients ingredients = new ingredients();
                return ingredients;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return tabCount;
    }
}
