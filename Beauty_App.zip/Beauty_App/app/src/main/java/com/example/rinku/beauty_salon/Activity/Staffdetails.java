package com.example.rinku.beauty_salon.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.MainActivity;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import retrofit2.Call;
import retrofit2.Callback;

public class Staffdetails extends AppCompatActivity {

    Toolbar toolbar1;
    ImageView staff_image;
    APIClient apiService;
    Float ratingval;
    String customer_id,staff_id, review;
    EditText reviewED;
    RatingBar ratingBar;
    Button submitRateBtn, cancelRateBtn;
    TextView staff_name, staff_gender, staff_email, staff_start_time, staff_end_time, staff_skillname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staffdetails);

        apiService = RetroClient.getClient().create(APIClient.class);

        GetValues getValues = new GetValues(Staffdetails.this);
        SharedPreferences prefs = getSharedPreferences("myPref", MODE_PRIVATE);
        customer_id = prefs.getString("CUSTOMERID", getValues.cid());
        staff_id = getIntent().getStringExtra("id");


        staff_name = findViewById(R.id.staff_name);
        staff_gender = findViewById(R.id.staff_gender);
        staff_image = findViewById(R.id.staff_image);
        staff_email = findViewById(R.id.staff_email);
        staff_start_time = findViewById(R.id.staff_start_time);
        staff_end_time = findViewById(R.id.staff_end_time);
        staff_skillname = findViewById(R.id.staff_skillname);
        ratingBar = findViewById(R.id.ratingBar);
        submitRateBtn = findViewById(R.id.submitRateBtn);
        cancelRateBtn = findViewById(R.id.cancelRateBtn);
        reviewED = findViewById(R.id.reviewED);

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                ratingval = (Float) ratingBar.getRating();
                String.valueOf(ratingval);

            }
        });

        submitRateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                review = reviewED.getText().toString();

                Poststaff_rating(staff_id, customer_id, ratingval, review);
                Toast.makeText(Staffdetails.this, "Stylist Rate Successfully", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(Staffdetails.this,MainActivity.class);
                startActivity(intent);
            }
        });



        android.support.v7.widget.Toolbar toolbar1 = findViewById (R.id.toolbar1);
        toolbar1.setTitle (R.string.staffdetail);
        setSupportActionBar (toolbar1);
        if (getSupportActionBar () != null) {
            getSupportActionBar ().setDisplayHomeAsUpEnabled (true);
            getSupportActionBar ().setDisplayShowHomeEnabled (true);
        }

        String staff_name1 = getIntent().getStringExtra("staffname");
        String image = getIntent().getStringExtra("staffimage");
        String gender = getIntent().getStringExtra("gender");
        String email = getIntent().getStringExtra("email");
        String starttime = getIntent().getStringExtra("starttime");
        String endtime = getIntent().getStringExtra("endtime");
        String skillname = getIntent().getStringExtra("skillname");


        Glide.with(this).load(image).into(staff_image);

        staff_name.setText(staff_name1);
        staff_gender.setText(gender);
        staff_email.setText(email);
        staff_start_time.setText(starttime);
        staff_end_time.setText(endtime);
        staff_skillname.setText(skillname);


    }

    private void Poststaff_rating(String staff_id, String customer_id, Float ratingval, String review) {
        Call <Example> call = apiService.Poststaff_rating(staff_id, customer_id, ratingval, review);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                Log.d("DATARES", "DATATABLE" + response + call);
                try {

                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Log.e(">> ", t.toString());
                Toast.makeText(Staffdetails.this, "Connection Error", Toast.LENGTH_SHORT).show();
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return super.onOptionsItemSelected(item);
    }

}
