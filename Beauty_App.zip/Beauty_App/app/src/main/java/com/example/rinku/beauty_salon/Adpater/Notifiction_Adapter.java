package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.rinku.beauty_salon.Notification.notification;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;

public class Notifiction_Adapter extends RecyclerView.Adapter<Notifiction_Adapter.MyViewHolder> {
    private List<Datum> dataSet;
    Context context;

    public Notifiction_Adapter(List<Datum> data, notification notification) {
        dataSet=data;
        context=notification;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView noti_detail;

        public MyViewHolder(View itemView) {
            super (itemView);
            this.noti_detail = (TextView) itemView.findViewById (R.id.noti_detail);
        }
    }
    @Override
    public Notifiction_Adapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.notifaction, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder (view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final Notifiction_Adapter.MyViewHolder holder, final int listPosition) {
        holder.noti_detail.setText (dataSet.get (listPosition).getMessage ());
    }


    @Override
    public int getItemCount() {
        return dataSet.size ();
    }
}
