package com.example.rinku.beauty_salon.Adpater;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Activity.Conform_appoinment;
import com.example.rinku.beauty_salon.Gole;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;


public class ComformAppoinment_Adapter extends RecyclerView.Adapter<ComformAppoinment_Adapter.MyViewHolder>{
    private List<Datum> dataSet;
    Conform_appoinment context;

    public ComformAppoinment_Adapter(List<Datum> data, Conform_appoinment conform_appoinment) {

        dataSet = data;
        context = conform_appoinment;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView s_name;
        TextView s_price;
        ImageView s_img;
       // ImageButton delete;
        CardView card_view;

        public MyViewHolder(View itemView) {
            super (itemView);
            this.s_name = (TextView) itemView.findViewById (R.id.s_name);
            this.s_price = (TextView) itemView.findViewById (R.id.s_price);
            this.s_img = (ImageView) itemView.findViewById (R.id.s_img);
            this.card_view = (CardView) itemView.findViewById (R.id.card_view);
         // this.delete = (ImageButton) itemView.findViewById (R.id.delete);
        }
    }

    @NonNull
    @Override
    public ComformAppoinment_Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from (viewGroup.getContext ()).inflate (R.layout.conformappointment_layout, viewGroup, false);
        MyViewHolder myViewHolder = new MyViewHolder (view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ComformAppoinment_Adapter.MyViewHolder myViewHolder, final int i) {
        myViewHolder.s_name.setText (dataSet.get (i).getServiceName ());
        myViewHolder.s_price.setText (dataSet.get (i).getPrice ());
        Glide.with (context).load (dataSet.get (i).getImage ()).into (myViewHolder.s_img);

//        myViewHolder.delete.setOnClickListener (new View.OnClickListener () {
//            @Override
//            public void onClick(View v) {
//               // context.Postdeletecard(dataSet.get(i).getServiceId ());
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return dataSet.size ();
    }
}
