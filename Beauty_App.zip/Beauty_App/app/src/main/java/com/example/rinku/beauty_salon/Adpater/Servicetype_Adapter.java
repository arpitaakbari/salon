package com.example.rinku.beauty_salon.Adpater;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Activity.Service_Type;
import com.example.rinku.beauty_salon.Activity.Servicesdetails;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;
import java.util.Random;

public class Servicetype_Adapter extends RecyclerView.Adapter<Servicetype_Adapter.MyViewHolder> {
    private List<Datum> dataSet;
    Service_Type context;

    public Servicetype_Adapter(List<Datum> data, Service_Type service_type) {
        dataSet = data;
        context = service_type;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        CardView card_view;
        TextView s_name;
//        TextView s_time;
        TextView s_price;
        ImageView s_img;
        Button addcart;
        ImageButton Wishlist1;

        public MyViewHolder(View itemView) {
            super (itemView);
            this.card_view=(CardView)itemView.findViewById(R.id.card_view);
            this.s_name = (TextView) itemView.findViewById (R.id.s_name);
            this.s_price = (TextView) itemView.findViewById (R.id.s_price);
            this.s_img = (ImageView) itemView.findViewById (R.id.s_img);
            this.addcart = (Button) itemView.findViewById (R.id.addcart);
            this.Wishlist1 = (ImageButton) itemView.findViewById (R.id.Wishlist1);
//            Wishlist1.setColorFilter(Color.argb(255, 255, 255, 255)); // White Tint
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from (viewGroup.getContext ()).inflate (R.layout.servicetype_layout, viewGroup, false);
        MyViewHolder myViewHolder = new MyViewHolder (view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, final int i) {

//        Random mRandom = new Random();
//        final int color = Color.argb(255, mRandom.nextInt(256), mRandom.nextInt(256), mRandom.nextInt(256));
//        ((GradientDrawable) myViewHolder.Wishlist1.getBackground()).setColor(color);


        myViewHolder.s_name.setText (dataSet.get (i).getName ());
        myViewHolder.s_price.setText (dataSet.get (i).getPrice ());
        Glide.with (context).load (dataSet.get (i).getImage ()).into (myViewHolder.s_img);
        myViewHolder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context,Servicesdetails.class);
                intent.putExtra("id",dataSet.get(i).getId());
                intent.putExtra("servicename",dataSet.get(i).getName());
                intent.putExtra("serviceprice",dataSet.get(i).getPrice());
                intent.putExtra("serviceimage",dataSet.get(i).getImage());
                intent.putExtra("serviceimg2",dataSet.get(i).getImage2());
                intent.putExtra("serviceimg3",dataSet.get(i).getImage3());
                intent.putExtra("serviceduration",dataSet.get(i).getDuration());
                intent.putExtra("servicematerils",dataSet.get(i).getMaterils());
                context.startActivity (intent);
//                context.PostAddcart1(dataSet.get(i).getId());
            }
        });
        myViewHolder.Wishlist1.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
//                if (myViewHolder.Wishlist1.getColorFilter()!=null){
//                    myViewHolder.Wishlist1.clearColorFilter();
//                }
//                else {
//                    myViewHolder.Wishlist1.setColorFilter(ContextCompat.getColor(context,R.color.bg_row_background));
//
//                }
                context.PostWishlist (dataSet.get (i).getId ());

            }
        });
        myViewHolder.addcart.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                context.PostAddcart (dataSet.get (i).getId ());
            }
        });

    }
    @Override
    public int getItemCount() {
        return dataSet.size ();
    }
}
