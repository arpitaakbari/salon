package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Activity.Appointment;
import com.example.rinku.beauty_salon.Gole;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;

public class Staffmaster_adapter extends RecyclerView.Adapter<Staffmaster_adapter.MyViewHolder> {
    private List<Datum> dataSet;
    Context context;
    String positionVal="0";

    public Staffmaster_adapter(Appointment appointment, List<Datum> data) {
        dataSet = data;
        context = appointment;
    }

    @NonNull
    @Override
    public Staffmaster_adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemview = LayoutInflater.from (viewGroup.getContext ()).inflate (R.layout.staff_layout, null);
        return new Staffmaster_adapter.MyViewHolder (itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int listPosition) {
        holder.staff_name.setText (dataSet.get (listPosition).getName ());
        Glide.with (context).load (dataSet.get (listPosition).getImage ()).into (holder.staff_image);

        if (positionVal.equals("")) {
            holder.staff_card.setBackground(context.getResources().getDrawable(R.drawable.stroke_invisible));
        } else if (listPosition == Integer.parseInt(positionVal)) {
            holder.staff_card.setBackground(context.getResources().getDrawable(R.drawable.stroke_visible));
        } else {
            holder.staff_card.setBackground(context.getResources().getDrawable(R.drawable.stroke_invisible));
        }
        holder.staff_card.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Gole.staff_name1 = dataSet.get (listPosition).getName ();
                Gole.staff_id = dataSet.get (listPosition).getId ();
                positionVal = String.valueOf(listPosition);
                notifyDataSetChanged ();
            }
        });
    }


    @Override
    public int getItemCount() {
        return dataSet.size ();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView staff_name;
        ImageView staff_image;
        CardView staff_card;

        public MyViewHolder(@NonNull View itemView) {
            super (itemView);
            this.staff_card = (CardView) itemView.findViewById (R.id.staff_card);
            this.staff_name = (TextView) itemView.findViewById (R.id.staff_name);
            this.staff_image = (ImageView) itemView.findViewById (R.id.staff_image);
        }
    }
}
