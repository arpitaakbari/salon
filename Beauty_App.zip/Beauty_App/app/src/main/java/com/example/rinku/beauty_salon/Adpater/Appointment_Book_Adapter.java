package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.rinku.beauty_salon.Drwer_Appointment.Book_appointment_Fragment;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;

public class Appointment_Book_Adapter extends RecyclerView.Adapter<Appointment_Book_Adapter.MyViewHolder> {
    private List<Datum> dataSet;
    Book_appointment_Fragment contxt1;

    public Appointment_Book_Adapter(List<Datum> data, Book_appointment_Fragment book_appointment_fragment) {
        dataSet=data;
        contxt1=book_appointment_fragment;
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView s_price;
        TextView txt_time;
        TextView txt_date;
        TextView txt_services;
        ImageButton btn_appointment_delete,btn_appointment_postponse;

        public MyViewHolder(View itemView) {
            super (itemView);
            this.s_price = itemView.findViewById (R.id.s_price);
            this.txt_time = itemView.findViewById (R.id.txt_time);
            this.txt_date = itemView.findViewById (R.id.txt_date);
            this.txt_services=itemView.findViewById (R.id.txt_services);
            this.btn_appointment_delete=itemView.findViewById (R.id.btn_appointment_delete);
//            this.btn_appointment_postponse=itemView.findViewById(R.id.btn_appointment_postponse);
        }
    }

    @Override
    public Appointment_Book_Adapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.appoinment_layout, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder (view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final Appointment_Book_Adapter.MyViewHolder holder, final int listPosition) {

        holder.s_price.setText (dataSet.get (listPosition).getPrice ());
        holder.txt_time.setText (dataSet.get (listPosition).getTime ());
        holder.txt_date.setText (dataSet.get (listPosition).getDate ());
        holder.txt_services.setText (dataSet.get (listPosition).getServiceName ());

        holder.btn_appointment_delete.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                contxt1.Postdelete_appointment(dataSet.get(listPosition).getServiceId ());

            }
        });
    }


    @Override
    public int getItemCount() {
        return dataSet.size ();
    }
}
