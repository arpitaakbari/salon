package com.example.rinku.beauty_salon.Adpater;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.rinku.beauty_salon.Activity.Appointment;
import com.example.rinku.beauty_salon.Gole;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;

public class Stafftime_adapter extends RecyclerView.Adapter <Stafftime_adapter.MyViewHolder>{
    private List<Datum> dataSet;
    Appointment context;
    String positionVa="0";

    public Stafftime_adapter(List<Datum> data, Appointment appointment) {
        dataSet = data;
        context = appointment;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemview = LayoutInflater.from (viewGroup.getContext ()).inflate (R.layout.time_salot, null);
        return new Stafftime_adapter.MyViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, final int i) {
        myViewHolder.tvfromtime.setText (dataSet.get (i).getTime ());

        if (positionVa.equals("")) {
            myViewHolder.time_card.setBackground(context.getResources().getDrawable(R.drawable.stroke_invisible));
        } else if (i == Integer.parseInt(positionVa)) {
            myViewHolder.time_card.setBackground(context.getResources().getDrawable(R.drawable.stroke_visible));
        } else {
            myViewHolder.time_card.setBackground(context.getResources().getDrawable(R.drawable.stroke_invisible));
        }
        myViewHolder.time_card.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Gole.time=dataSet.get (i).getTime ();
                positionVa = String.valueOf(i);
                notifyDataSetChanged ();
                context.postchkbooking (dataSet.get (i).getTime ());
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvfromtime;
        RelativeLayout time;
        CardView time_card;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            this.tvfromtime=itemView.findViewById(R.id.tvfromtime);
            this.time=itemView.findViewById (R.id.time);
            this.time_card=itemView.findViewById (R.id.time_card);
        }
    }
}
