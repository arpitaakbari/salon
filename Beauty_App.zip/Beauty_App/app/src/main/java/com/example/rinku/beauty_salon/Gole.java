package com.example.rinku.beauty_salon;

import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.security.PublicKey;

public class Gole {

    public static String staff_name1;
    public static String time;
    public static String staff_id;
    public static String joint;
    public static String service_id;
    public static String s_id;
    public static String Edit_Folder_name = "BeautySalon";


    public static boolean createDirIfNotExists(String path) {
        File file = new File(Environment.getExternalStorageDirectory(), "/" + path);
        if (file.exists()) {

            Log.d("MAINDATASUMIT" , "SUMIT" + "Can't create folder" );
            System.out.println("Can't create folder");
            return true;
        }
        file.mkdir();
        if (file.mkdirs()) {
            return true;
        }
        return false;
    }
}
