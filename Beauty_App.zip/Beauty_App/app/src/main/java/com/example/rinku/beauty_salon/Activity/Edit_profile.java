package com.example.rinku.beauty_salon.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import retrofit2.Call;
import retrofit2.Callback;

public class Edit_profile extends AppCompatActivity {

    EditText etname, etemail, etcontact, etgender;
    private APIClient apiService;
    String customer_id;
    ProgressDialog pDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        apiService = RetroClient.getClient().create(APIClient.class);
        etname = findViewById(R.id.etname);
        etemail = findViewById(R.id.etemail);
        etcontact = findViewById(R.id.etcontact);
        etgender = findViewById(R.id.etgender);

        SharedPreferences prefs = getSharedPreferences("myPref", MODE_PRIVATE);
        GetValues getValues = new GetValues(Edit_profile.this);
        customer_id = prefs.getString("CUSTOMERID", getValues.cid());
        etname.setText(getValues.mName());
        etemail.setText(getValues.mEmail());
        etcontact.setText(getValues.mPhono());
        etgender.setText(getValues.mGender());

        android.support.v7.widget.Toolbar toolbar = findViewById(R.id.toolbar_pro);
        setTitle("Edit profile");
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

        }


        ImageButton imageButton = findViewById(R.id.imgbtn_done);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String name = etname.getText().toString();
                final String email = etemail.getText().toString();
                final String phone_no = etcontact.getText().toString();
                final String gender = etgender.getText().toString();
                posteditprofile(name, email, phone_no, gender);

            }
        });
    }

    private void posteditprofile(final String name, final String email, final String phone_no, final String gender) {
        pDialog = new ProgressDialog(Edit_profile.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call <Example> call = apiService.editprofile(customer_id, name, email, phone_no, gender);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                try {

                    Log.d("DATARES", "DATATABLE" + response + call);
                    SharedPreferences.Editor editor = getApplicationContext().getSharedPreferences("myPref", MODE_PRIVATE).edit();
                    editor.putString("NAME", name);
                    editor.putString("EMAIL", email);
                    editor.putString("PHONO", phone_no);
                    editor.putString("GENDER", gender);
                    editor.commit();
                    Intent intent = new Intent(Edit_profile.this, My_profile.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    pDialog.dismiss();
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Log.d("DATARES", "DATATABLE" + t + call);
                Toast.makeText(Edit_profile.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return super.onOptionsItemSelected(item);
    }

}
