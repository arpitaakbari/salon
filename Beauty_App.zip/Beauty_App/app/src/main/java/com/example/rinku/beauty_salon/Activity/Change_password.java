package com.example.rinku.beauty_salon.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.CardView;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.example.rinku.beauty_salon.MainActivity;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import retrofit2.Call;
import retrofit2.Callback;

public class Change_password extends AppCompatActivity {

    EditText edittxt_current_psd, edittxt_new_psd, edittxt_con_psd;
    CardView card_submit, card_cancel;
    private APIClient apiService;
    String customer_id;
    AppCompatCheckBox chk;
    ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_changepassword__main);

        chk=findViewById(R.id.chk);
        chk.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (! isChecked){
                    edittxt_current_psd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    edittxt_new_psd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    edittxt_con_psd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                else {
                    edittxt_current_psd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    edittxt_new_psd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    edittxt_con_psd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });
        apiService = RetroClient.getClient ().create (APIClient.class);
        android.support.v7.widget.Toolbar toolbar = findViewById (R.id.toolbar_con);
        setTitle(R.string.cwd);
        setSupportActionBar (toolbar);
        if (getSupportActionBar () != null) {
            getSupportActionBar ().setDisplayHomeAsUpEnabled (true);
            getSupportActionBar ().setDisplayShowHomeEnabled (true);
        }
        SharedPreferences prefs = getSharedPreferences ("myPref", MODE_PRIVATE);
        GetValues getValues = new GetValues (Change_password.this);
        customer_id = prefs.getString ("CUSTOMERID", getValues.cid ());

        edittxt_current_psd = findViewById (R.id.edittxt_current_psd);
        edittxt_new_psd = findViewById (R.id.edittxt_new_psd);
        edittxt_con_psd = findViewById (R.id.edittxt_con_psd);
        card_submit = findViewById (R.id.card_submit);
        card_cancel = findViewById (R.id.card_cancel);

        card_submit.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                final String current_passwd = edittxt_current_psd.getText ().toString ();
                final String new_passwd = edittxt_new_psd.getText ().toString ();
                final String confrom_passwd = edittxt_con_psd.getText ().toString ();
                if (current_passwd.isEmpty() && new_passwd.isEmpty() && confrom_passwd.isEmpty() ){
                    Toast.makeText(Change_password.this, "Please enter all values", Toast.LENGTH_SHORT).show();
                }
                else {
                    posteditprofile (current_passwd, new_passwd, confrom_passwd);

                }

            }
        });
    }

    private void posteditprofile(String current_passwd, String new_passwd, String confrom_passwd) {
        pDialog = new ProgressDialog(Change_password.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call<Example> call = apiService.changepasswd (current_passwd, new_passwd, confrom_passwd, customer_id);
        call.enqueue (new Callback<Example> () {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                Log.d ("DATARES", "DATATABLE" + response + call);
                try {

                pDialog.dismiss();
                Toast.makeText (Change_password.this, "change password successfully", Toast.LENGTH_SHORT).show ();
                    Intent intent=new Intent(Change_password.this, MainActivity.class);
                    startActivity(intent);
            }catch (Exception e){
                }
            }
            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.d ("DATARES", "DATATABLE" + t + call);
                Toast.makeText (Change_password.this, "Connection Error", Toast.LENGTH_SHORT).show ();
                pDialog.dismiss();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId () == android.R.id.text1) ;
        finish ();
        return super.onOptionsItemSelected (item);
    }

}
