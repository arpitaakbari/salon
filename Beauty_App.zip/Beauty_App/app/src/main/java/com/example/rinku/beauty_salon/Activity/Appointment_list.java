package com.example.rinku.beauty_salon.Activity;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.example.rinku.beauty_salon.Drwer_Appointment.Book_appointment_Fragment;
import com.example.rinku.beauty_salon.Drwer_Appointment.History_appointment_Fragment;
import com.example.rinku.beauty_salon.Drwer_Appointment.Tabadapter_appoitment;
import com.example.rinku.beauty_salon.R;

public class Appointment_list extends AppCompatActivity {

    private Tabadapter_appoitment adapter;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment__main);

        Toolbar toolbar = findViewById (R.id.toolbar);
        setTitle(R.string.Appoinment);
        setSupportActionBar (toolbar);
        if (getSupportActionBar () != null) {
            getSupportActionBar ().setDisplayHomeAsUpEnabled (true);
            getSupportActionBar ().setDisplayShowHomeEnabled (true);
        }
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        adapter = new Tabadapter_appoitment (getSupportFragmentManager());
        adapter.addFragment(new Book_appointment_Fragment(), "UPCOMING");
        adapter.addFragment(new History_appointment_Fragment(), "HISTORY");

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId ()==android.R.id.text1);
        finish ();
        return super.onOptionsItemSelected (item);
    }

}
