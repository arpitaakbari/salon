package com.example.rinku.beauty_salon.Rest;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Datum {
    boolean selected;

    @SerializedName("id")
    @Expose
    private String id;

    @SerializedName("image3")
    @Expose
    private String image3;

    @SerializedName("image2")
    @Expose
    private String image2;

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("time")
    @Expose
    private String time;

    @SerializedName("service_category_id")
    @Expose
    private String serviceCategoryId;

    @SerializedName("name")
    @Expose
    private String name;

    @SerializedName("image")
    @Expose
    private String image;

    @SerializedName("skill_id")
    @Expose
    private String skillId;

    @SerializedName("password")
    @Expose
    private String password;

    @SerializedName("starttime")
    @Expose
    private String starttime;

    @SerializedName("endtime")
    @Expose
    private String endtime;


    @SerializedName("time_from")
    @Expose
    private String timeFrom;

    @SerializedName("time_to")
    @Expose
    private String timeTo;

    @SerializedName("description")
    @Expose
    private String description;

    @SerializedName("skill_name")
    @Expose
    private String skillName;

    @SerializedName("service_master_name")
    @Expose
    private String serviceMasterName;

    @SerializedName("price")
    @Expose
    private String price;

    @SerializedName("materils")
    @Expose
    private String materils;

    @SerializedName("duration")
    @Expose
    private String duration;

    @SerializedName("date")
    @Expose
    private String date;

    @SerializedName("title")
    @Expose
    private String title;

    @SerializedName("added_by")
    @Expose
    private String addedBy;

    @SerializedName("discount")
    @Expose
    private String discount;

    @SerializedName("service_name")
    @Expose
    private String serviceName;

    @SerializedName("email")
    @Expose
    private String email;

    @SerializedName("phone_no")
    @Expose
    private String phoneNo;

    @SerializedName("gender")
    @Expose
    private String gender;
    @SerializedName("service_category")
    @Expose
    private String serviceCategory;

    @SerializedName("customer_id")
    @Expose
    private String customerId;

    @SerializedName("service_id")
    @Expose
    private String serviceId;

    @SerializedName("staff_id")
    @Expose
    private String staffId;

    @SerializedName("rating")
    @Expose
    private String rating;

    @SerializedName("complation")
    @Expose
    private String complation;

    @SerializedName("review")
    @Expose
    private String review;

    @SerializedName("used")
    @Expose
    private String used;

    @SerializedName("ingredients")
    @Expose
    private String ingredients;


    public String getUsed() {
        return used;
    }

    public void setUsed(String used) {
        this.used = used;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getComplation() {
        return complation;
    }

    public void setComplation(String complation) {
        this.complation = complation;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }


    public String getImage3() {
        return image3;
    }

    public void setImage3(String image3) {
        this.image3 = image3;
    }


    public String getImage2() {
        return image2;
    }

    public void setImage2(String image2) {
        this.image2 = image2;
    }

    public String getSkillName() {
        return skillName;
    }

    public void setSkillName(String skillName) {
        this.skillName = skillName;
    }


    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }


    public String getServiceCategoryId() {
        return serviceCategoryId;
    }

    public void setServiceCategoryId(String serviceCategoryId) {
        this.serviceCategoryId = serviceCategoryId;
    }


    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAddedBy() {
        return addedBy;
    }

    public void setAddedBy(String addedBy) {
        this.addedBy = addedBy;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getServiceMasterName() {
        return serviceMasterName;
    }

    public void setServiceMasterName(String serviceMasterName) {
        this.serviceMasterName = serviceMasterName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getMaterils() {
        return materils;
    }

    public void setMaterils(String materils) {
        this.materils = materils;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getServiceCategory() {
        return serviceCategory;
    }

    public void setServiceCategory(String serviceCategory) {
        this.serviceCategory = serviceCategory;
    }


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getTimeFrom() {
        return timeFrom;
    }

    public void setTimeFrom(String timeFrom) {
        this.timeFrom = timeFrom;
    }

    public String getTimeTo() {
        return timeTo;
    }

    public void setTimeTo(String timeTo) {
        this.timeTo = timeTo;
    }


    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}