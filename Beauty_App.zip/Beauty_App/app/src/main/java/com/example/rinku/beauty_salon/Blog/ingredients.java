package com.example.rinku.beauty_salon.Blog;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.rinku.beauty_salon.R;

public class ingredients extends Fragment {

    TextView blog_ingredients;
    String blogingredients;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        Bundle b = getActivity().getIntent().getExtras();
        blogingredients = b.getString("ingredients");

        View view= inflater.inflate(R.layout.ingredients, container, false);

        blog_ingredients=view.findViewById(R.id.blog_ingredients);
        blog_ingredients.setText(Html.fromHtml(blogingredients));
        return view;
    }
}
