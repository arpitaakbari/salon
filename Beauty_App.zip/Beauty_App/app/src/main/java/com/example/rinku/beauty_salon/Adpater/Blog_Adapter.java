package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Blog.Blog_detail;
import com.example.rinku.beauty_salon.Blog.Blogs;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;

public class Blog_Adapter extends RecyclerView.Adapter <Blog_Adapter.MyViewHolder> {
    private List <Datum> dataSet;
    Context context;
    private int lastPosition = -1;
    private View view;

    public Blog_Adapter(List <Datum> data, Blogs blogs) {
        dataSet = data;
        context = blogs;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textViewtitle;
        ImageView imageViewblog;
        CardView card_view;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.card_view = itemView.findViewById(R.id.card_view);
            this.textViewtitle = (TextView) itemView.findViewById(R.id.trips_title);
            this.imageViewblog = (ImageView) itemView.findViewById(R.id.blog_img);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.blog_layout, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int listPosition) {

        holder.textViewtitle.setText(dataSet.get(listPosition).getTitle());
        //holder.textViewdetail.setText (Html.fromHtml (dataSet.get (listPosition).getDescription ()));
        Glide.with(context).load(dataSet.get(listPosition).getImage()).into(holder.imageViewblog);


        holder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(context, Blog_detail.class);
                mainIntent.putExtra("title", dataSet.get(listPosition).getTitle());
                mainIntent.putExtra("detail", dataSet.get(listPosition).getDescription());
                mainIntent.putExtra("used",dataSet.get(listPosition).getUsed());
                mainIntent.putExtra("ingredients",dataSet.get(listPosition).getIngredients());
                mainIntent.putExtra("image", dataSet.get(listPosition).getImage());
                context.startActivity(mainIntent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }
}
