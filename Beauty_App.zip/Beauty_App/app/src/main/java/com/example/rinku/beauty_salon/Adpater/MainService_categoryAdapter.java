package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Activity.Service_Master;
import com.example.rinku.beauty_salon.Activity.Main_serviceActivity;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;
import java.util.List;

public class MainService_categoryAdapter extends RecyclerView.Adapter<MainService_categoryAdapter.ViewHolder>{

    List<Datum> dataset;
    Context context;

    public MainService_categoryAdapter(Main_serviceActivity main_serviceActivity, List<Datum> data) {
        context=main_serviceActivity;
        dataset=data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemview = LayoutInflater.from (viewGroup.getContext ()).inflate (R.layout.mainservices, null);
        return new MainService_categoryAdapter.ViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {
        viewHolder.cat_name.setText (dataset.get (i).getName ());
        Glide.with (context).load (dataset.get (i).getImage ()).into (viewHolder.hair_image);

        viewHolder.service_card.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent (context, Service_Master.class);
                mainIntent.putExtra ("image", dataset.get(i).getImage ());
                mainIntent.putExtra ("id",dataset.get (i).getId ());
                context.startActivity (mainIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView hair_image;
        private TextView cat_name;
        CardView service_card;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            hair_image = (ImageView) itemView.findViewById (R.id.hair_image);
            cat_name = (TextView) itemView.findViewById (R.id.cat_name);
            service_card = (CardView) itemView.findViewById (R.id.service_card);
        }
    }
}
