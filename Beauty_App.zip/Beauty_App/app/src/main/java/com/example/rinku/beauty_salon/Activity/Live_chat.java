package com.example.rinku.beauty_salon.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Live_chat extends AppCompatActivity {

    ListView listView;
    private ArrayAdapter <String> arrayAdapter;
    private ArrayList <String> list_of_room = new ArrayList <>();
    EditText room_name;
    Button add_room;
    String name,customer_name;
    private DatabaseReference root = FirebaseDatabase.getInstance().getReference().getRoot();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_chat);

        GetValues getValues = new GetValues(Live_chat.this);
        SharedPreferences prefs = getSharedPreferences("myPref", MODE_PRIVATE);
        customer_name = prefs.getString("NAME", getValues.mName());

        room_name = findViewById(R.id.room_name);
        add_room = findViewById(R.id.add_room);
        listView = findViewById(R.id.listview);

        android.support.v7.widget.Toolbar toolbar1 = findViewById(R.id.toolbar1);
        toolbar1.setTitle(R.string.chat);
        setSupportActionBar(toolbar1);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        arrayAdapter = new ArrayAdapter <String>(this, android.R.layout.simple_list_item_1, list_of_room);
        listView.setAdapter(arrayAdapter);
        request_user_name();

        add_room.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map <String, Object> map = new HashMap <String, Object>();
                map.put(add_room.getText().toString(), "");
                root.updateChildren(map);
            }
        });

        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Set<String> set = new HashSet<String>();
                Iterator i = dataSnapshot.getChildren().iterator();

                while (i.hasNext()){
                    set.add(((DataSnapshot)i.next()).getKey());
                }

                list_of_room.clear();
                list_of_room.addAll(set);

                arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(getApplicationContext(),Chat_room.class);
                intent.putExtra("room_name",((TextView)view).getText().toString() );
                intent.putExtra("user_name",name);
                startActivity(intent);
            }
        });
    }


    private void request_user_name() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Chat As:");
        final TextView input_field = new TextView(this);
        input_field.setText(customer_name);
        input_field.setTextSize(20);
        input_field.setPadding(50,20,50,0);
        builder.setView(input_field);

        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                name = input_field.getText().toString();
            }
        });
        builder.setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                request_user_name();
            }
        });
        builder.show();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return super.onOptionsItemSelected(item);
    }
}
