package com.example.rinku.beauty_salon.Rest;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface APIClient {

    @FormUrlEncoded
    @POST("api/login.php")
    Call <Example> PostLoginApi(@Field("email") String email, @Field("password") String password);

    @FormUrlEncoded
    @POST("api/signup.php")
    Call <Example> PostregisterApi(@Field("name") String name, @Field("email") String email, @Field("password") String password, @Field("phone_no") String phone_no, @Field("gender") String gender, @Field("city") String city);

    @GET("api/blog-list.php")
    Call <Example> getBloglist();

    @GET("api/package-list.php")
    Call <Example> GetPackagelist();

    @GET("api/offers-list.php")
    Call <Example> GetOfferlist();

    @FormUrlEncoded
    @POST("api/get-service-list.php")
    Call <Example> Postservicetype(@Field("id") String id);

    @GET("api/service_category-list.php")
    Call <Example> Getservice_categorylist();

    @FormUrlEncoded
    @POST("api/get-cat.php")
    Call <Example> Postlist(@Field("id") String id);

    @GET("api/staff-list.php")
    Call <Example> Getstafflist();

    @GET("api/slot-time.php")
    Call <Example> Gettimeslotlist();

    @GET("api/staff-time-slot.php")
    Call <Example> Gettimeslot_list();

    @FormUrlEncoded
    @POST("api/cart-insert.php")
    Call <Example> Postaddcart(@Field("service_id") String service_id, @Field("customer_id") String customer_id);

    @FormUrlEncoded
    @POST("api/cart-list.php")
    Call <Example> postAddlist(@Field("id") String customer_id1);

    @FormUrlEncoded
    @POST("api/wishlist-list.php")
    Call <Example> Postwishlist(@Field("id") String customer_id1);

    @FormUrlEncoded
    @POST("api/wish-insert.php")
    Call <Example> Postwishlistadd(@Field("service_id") String service_id, @Field("customer_id") String customer_id);

    @FormUrlEncoded
    @POST("api/cart-delete.php")
    Call <Example> postdeletecard(@Field("service_id") String service_id, @Field("customer_id") String customer_id1);

    @FormUrlEncoded
    @POST("api/wishlist-delete.php")
    Call <Example> postdeletewishlist(@Field("service_id") String service_id, @Field("customer_id") String customer_id1);


    @FormUrlEncoded
    @POST("api/check-booking.php")
    Call <Example> postchkbooking(@Field("time") String s, @Field("date") String s1, @Field("staff_id") String s2, @Field("service_id") String s3);

    @FormUrlEncoded
    @POST("api/appoinment-insert.php")
    Call <Example> postbookapp_insert(@Field("time") String time, @Field("staff_id") String staff_name, @Field("date") String date, @Field("customer_id") String customer_id1, @Field("service_id") String service_id);

    @FormUrlEncoded
    @POST("api/edit-profile.php")
    Call <Example> editprofile(@Field("id") String customer_id, @Field("name") String name, @Field("email") String email, @Field("phone_no") String phone_no, @Field("gender") String gender);

    @FormUrlEncoded
    @POST("api/chg-password.php")
    Call <Example> changepasswd(@Field("password") String current_passwd, @Field("newpass") String new_passwd, @Field("conformpass") String confrom_passwd, @Field("id") String customer_id);

    @FormUrlEncoded
    @POST("api/history-user.php")
    Call <Example> appointment_history(@Field("id") String customer_id);

    @FormUrlEncoded
    @POST("api/delete-history.php")
    Call <Example> delete_appointment_history(@Field("customer_id") String c_id, @Field("service_id") String service_id);

    @FormUrlEncoded
    @POST("api/history-appoinment.php")
    Call <Example> post_appointment_history(@Field("id") String customer_id);

    @GET("api/notification-list.php")
    Call <Example> getnoti_list();

    @FormUrlEncoded
    @POST("api/service-rating-list.php")
    Call <Example> Postservice_rating(@Field("customer_id") String customer_id, @Field("service_id") String service_id, @Field("rating") Float rating, @Field("review") String review);

    @FormUrlEncoded
    @POST("api/staff-rating-list.php")
    Call <Example> Poststaff_rating(@Field("staff_id") String staff_name1, @Field("customer_id") String customer_id, @Field("rating") Float rating, @Field("review") String review);
}
