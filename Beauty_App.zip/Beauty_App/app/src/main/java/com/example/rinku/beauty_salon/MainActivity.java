package com.example.rinku.beauty_salon;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rinku.beauty_salon.Blog.Blogs;
import com.example.rinku.beauty_salon.Activity.AddCart;
import com.example.rinku.beauty_salon.Activity.Live_chat;
import com.example.rinku.beauty_salon.Activity.Login;
import com.example.rinku.beauty_salon.Activity.Main_serviceActivity;
import com.example.rinku.beauty_salon.Activity.Staffmaindot;
import com.example.rinku.beauty_salon.Adpater.Custom_Offer_Adapter;
import com.example.rinku.beauty_salon.Adpater.Staffmain_adapter;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;
import com.example.rinku.beauty_salon.Activity.Appointment_list;
import com.example.rinku.beauty_salon.Activity.Change_password;
import com.example.rinku.beauty_salon.Activity.Contcat_us;
import com.example.rinku.beauty_salon.Activity.My_profile;
import com.example.rinku.beauty_salon.Notification.notification;
import com.example.rinku.beauty_salon.Activity.Wishlist;
import com.example.rinku.beauty_salon.Activity.Packge;
import com.example.rinku.beauty_salon.Adpater.Servicecategory_adapter;

import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;

import static android.view.View.GONE;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    LinearLayout content;
    CardView card_blog;
    static final int DIALOG_ERROR_CONNECTION = 2;
    private static final Object MainActivity = 2;
    Toolbar toolbar;
    private static RecyclerView blog;
    ActionBarDrawerToggle actionBarDrawerToggle;
    RecyclerView recyclerView, service_category,staff_ry;
    private APIClient apiService;
    private String ShareContent;
    ImageButton pack_dot, service_dot, blog_dot,staff_dot;
    ProgressDialog pDialog;
    TextView message;
    String customer_id;
    int mCartItemCount = 0;
    TextView textCartItemCount;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        apiService = RetroClient.getClient().create(APIClient.class);
        GetValues getValues = new GetValues(MainActivity.this);
        SharedPreferences prefs = getSharedPreferences("myPref", MODE_PRIVATE);
        customer_id = prefs.getString("CUSTOMERID", getValues.cid());


        staff_ry=findViewById(R.id.staff_ry);
        staff_ry.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        getStafflist();


        card_blog=findViewById(R.id.card_blog);
        card_blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity((new Intent(MainActivity.this, Blogs.class)));
            }
        });
        blog=findViewById(R.id.blog);
        content = findViewById(R.id.content);
        staff_dot=findViewById(R.id.staff_dot);
        staff_dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity((new Intent(MainActivity.this, Staffmaindot.class)));
            }
        });
        service_dot = findViewById(R.id.service_dot);
        service_dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity((new Intent(MainActivity.this, Main_serviceActivity.class)));
            }
        });
        pack_dot = findViewById(R.id.pack_dot);
        pack_dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity((new Intent(MainActivity.this, AddCart.class)));
            }
        });

        blog_dot = findViewById(R.id.blog_dot);
        blog_dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Blogs.class);
                startActivity(intent);
            }
        });
        recyclerView = findViewById(R.id.viewpager);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        getOfferlist();

        service_category = findViewById(R.id.service_category);
        service_category.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        getservice_categorylist();


        if (!isOnline(this)) {
            showDialog(DIALOG_ERROR_CONNECTION);
        } else {
        }
        toolbar = findViewById(R.id.toolbar);
        setTitle(R.string.app_name);
        setSupportActionBar(toolbar);
        Button booknow = findViewById(R.id.book_now);
        booknow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity((new Intent(MainActivity.this, AddCart.class)));
            }
        });
        ImageButton packge_image = findViewById(R.id.packge_image);
        packge_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity((new Intent(MainActivity.this, Packge.class)));
            }
        });
        final ImageButton blog = findViewById(R.id.blog_image);
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity((new Intent(MainActivity.this, Blogs.class)));
            }
        });

        if (!isOnline(this)) {
            showDialog(DIALOG_ERROR_CONNECTION);
        } else {
        }
        ImageView tcIcon = (ImageView) findViewById(R.id.tvIcon);
//        TextView textView = (TextView) findViewById(R.id.textview);
        Bundle mBundle = getIntent().getExtras();
        if (mBundle != null) {

            Random mRandom = new Random();
            final int color = Color.argb(255, mRandom.nextInt(256), mRandom.nextInt(256), mRandom.nextInt(256));
            tcIcon.setImageResource(R.drawable.navigation_header_img);
            ((GradientDrawable) tcIcon.getBackground()).setColor(mBundle.getInt("ColorIcon"));
//            textView.setText(mBundle.getString("name"));
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);

        final DrawerLayout drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer_layout.setScrimColor(Color.TRANSPARENT);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawer_layout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            private float scaleFactor = 6f;

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                float slideX = drawerView.getWidth() * slideOffset;
                content.setTranslationX(slideX);
                content.setScaleX(1 - (slideOffset / scaleFactor));
                content.setScaleY(1 - (slideOffset / scaleFactor));
            }
        };

        drawer_layout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        NavigationView nav_view=findViewById(R.id.nav_view);
        nav_view.setNavigationItemSelectedListener(this);
        fatchCartItem(customer_id);

    }

    protected void onStart() {
        super.onStart();
        fatchCartItem(customer_id);
    }

    private void fatchCartItem(String customer_id) {
        Call<Example> call = apiService.postAddlist(customer_id);
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                List<Datum> data = response.body ().getData ();
                if (response.body().getSuccess ().equals (0)) {
                    try {
                        mCartItemCount = 0;
                        setupBadge(mCartItemCount);
                    } catch (Exception ex) {
                    }
                } else {
                    try {
                        mCartItemCount =data.size();
                        setupBadge(mCartItemCount);
                    } catch (Exception ex) {
                    }
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.e(">> ", t.toString());
            }

        });
    }
    public void setupBadge(int upBadge) {
        if (textCartItemCount != null) {
            if (this.mCartItemCount == 0) {
                if (textCartItemCount.getVisibility() != View.GONE) {
                    textCartItemCount.setVisibility(View.GONE);
                }
            } else {
                textCartItemCount.setText(String.valueOf(Math.min(this.mCartItemCount, upBadge)));
                if (textCartItemCount.getVisibility() != View.VISIBLE) {
                    textCartItemCount.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    private void getStafflist() {
        try {
//            pDialog = new ProgressDialog(MainActivity.this);
//            pDialog.setMessage("Please wait...");
//            pDialog.setIndeterminate(false);
//            pDialog.setCancelable(false);
//            pDialog.show();
            Call <Example> call = apiService.Getstafflist();
            call.enqueue(new Callback <Example>() {
                @Override
                public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                    List <Datum> data = response.body().getData();
                    try {

//                        pDialog.dismiss();
                        staff_ry.setAdapter(new Staffmain_adapter(MainActivity.this, data));
                        Log.d("DATAMAIN", "DATAonResponse:" + data);
                    } catch (Exception e) {
                    }
                }

                @Override
                public void onFailure(Call <Example> call, Throwable t) {
                    System.out.print("Fail");
//                    pDialog.dismiss();
                }
            });
        } catch (Exception ex) {

        }
    }

    private void getservice_categorylist() {
        pDialog = new ProgressDialog(MainActivity.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call <Example> call = apiService.Getservice_categorylist();
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                List <Datum> data = response.body().getData();
                try {
                    if (data == null) {
                        service_category.setVisibility(GONE);
                        pDialog.dismiss();
                    } else {
                        pDialog.dismiss();
                        Log.d("DATAMAIN", "DATAonResponse:" + data);
                        service_category.setAdapter(new Servicecategory_adapter(MainActivity.this, data));
                    }
                } catch (Exception e) {

                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Try......again", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    private void getOfferlist() {
        Call <Example> call = apiService.GetOfferlist();
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                List <Datum> data = response.body().getData();
                try {
                    if (data == null) {
                        recyclerView.setVisibility(GONE);
                        pDialog.dismiss();
                    } else {
                        pDialog.dismiss();
                        recyclerView.setAdapter(new Custom_Offer_Adapter(MainActivity.this, data));
                        Log.d("DATAMAI`N", "DATAonResponse:" + data);
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
//                Log.d("MainActivity", t.getMessage());
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer_layout.isDrawerOpen(GravityCompat.START)) {
            drawer_layout.closeDrawer(GravityCompat.START);
        } else super.onBackPressed();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.cart, menu);
        final MenuItem menuItem = menu.findItem(R.id.action_cart);
        View actionView = MenuItemCompat.getActionView(menuItem);
        textCartItemCount = (TextView) actionView.findViewById(R.id.cart_count);
        setupBadge(mCartItemCount);
        actionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddCart.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_cart:
                Intent intent = new Intent(MainActivity.this, AddCart.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return true;
            case R.id.chat_cart:
                Intent chat = new Intent(MainActivity.this, Live_chat.class);
                chat.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(chat);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        actionBarDrawerToggle.syncState();
    }

    public boolean isOnline(Context c) {
        ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        if (ni != null && ni.isConnected())
            return true;
        else return false;
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        switch (id) {
            case DIALOG_ERROR_CONNECTION:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setIcon(R.drawable.danger);
                builder.setTitle("Error");
                builder.setMessage("No internet connection.");
                builder.setPositiveButton(Html.fromHtml("<font color='#FF7F27'>ok</font>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.d("MainActivity", "ok");
                    }
                }).setNegativeButton(Html.fromHtml("<font color='#00000'>cancel</font>"), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Log.d("MainActivity", "cancel");
                        dialog.cancel();
                    }
                });
                builder.setCancelable(false);
                AlertDialog about = builder.create();
                about.show();
            default:
                break;
        }
        return dialog;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.Profile:
                MainActivity.this.startActivity(new Intent(MainActivity.this, My_profile.class));
                break;
            case R.id.packg:
                MainActivity.this.startActivity(new Intent(MainActivity.this, Packge.class));
                break;
            case R.id.Appoiment:
                MainActivity.this.startActivity(new Intent(MainActivity.this, Appointment_list.class));
                break;
            case R.id.Wishlist:
                MainActivity.this.startActivity(new Intent(MainActivity.this, Wishlist.class));
                break;
            case R.id.notification:
                MainActivity.this.startActivity(new Intent(MainActivity.this, notification.class));
                break;
            case R.id.contact:
                MainActivity.this.startActivity(new Intent(MainActivity.this, Contcat_us.class));
                break;
            case R.id.rate:
                MainActivity.this.showDefaultDialog();
                break;
            case R.id.changePassword:
                MainActivity.this.startActivity(new Intent(MainActivity.this, Change_password.class));
                break;
            case R.id.signout:
                MainActivity.this.dailog_sin();
                break;
            case R.id.share:
                Intent shareIntent = new Intent("android.intent.action.SEND");
                shareIntent.setType("text/plain");
                shareIntent.putExtra("android.intent.extra.TEXT", ShareContent + " " + "https://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(Intent.createChooser(shareIntent, "Share using"));
        }
        DrawerLayout drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer_layout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void showDefaultDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogCustomRate);
        builder.setTitle("Rate this App");
        builder.setMessage("If you enjoy using this app,would you mind taking a moment to rate it? it won't take more than a minute.Thank you for your support!");
        builder.setNegativeButton("NO,THANKS", null);
        builder.setNeutralButton("LATER", null);
        builder.setPositiveButton("RATE NOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getPackageName())));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "You don't have Google Play installed", Toast.LENGTH_SHORT).show();
                }
            }
        }).create().show();
    }

    public void dailog_sin() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogCustomSignOut);
        builder.setTitle("SignOut");
        builder.setMessage("Are you sure you want to signout?");
        builder.setNegativeButton("No", null);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SharedPreferences.Editor editor = getApplicationContext().getSharedPreferences("myPref", MODE_PRIVATE).edit();
                editor.clear();
                editor.commit();
                finish();
                Intent intent = new Intent(MainActivity.this, Login.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        }).create().show();
    }
}