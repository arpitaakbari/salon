package com.example.rinku.beauty_salon.Activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.MainActivity;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import retrofit2.Call;
import retrofit2.Callback;

public class Servicesdetails extends AppCompatActivity {

    private APIClient apiService;
    private static RecyclerView.Adapter adapter;
    Toolbar toolbar;
    String customer_id, service_id, review;
    EditText reviewED;
    Float ratingval;
    LinearLayout SliderDots;
    RelativeLayout r_rating;
    RatingBar ratingBar;
    Button submitRateBtn, addcart, cancelRateBtn;
    ImageButton Wishlist1;
    ProgressDialog pDialog;
    ImageView service_img, serviceimg2, serviceimg3;
    TextView service_name, service_price, service_matrials, service_duration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servicesdetails);

        apiService = RetroClient.getClient().create(APIClient.class);

        GetValues getValues = new GetValues(Servicesdetails.this);
        SharedPreferences prefs = getSharedPreferences("myPref", MODE_PRIVATE);
        customer_id = prefs.getString("CUSTOMERID", getValues.cid());
        service_id = getIntent().getStringExtra("id");

        ratingBar = findViewById(R.id.ratingBar);
        r_rating = findViewById(R.id.r_rating);
        reviewED = findViewById(R.id.reviewED);
        submitRateBtn = findViewById(R.id.submitRateBtn);
        cancelRateBtn = findViewById(R.id.cancelRateBtn);

        Wishlist1 = findViewById(R.id.Wishlist1);
        Wishlist1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PostWishlist1(service_id);
            }
        });
        addcart = findViewById(R.id.addcart);
        addcart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PostAddcart(service_id);
            }
        });

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                ratingval = (Float) ratingBar.getRating();
                String.valueOf(ratingval);

            }
        });

        submitRateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                review = reviewED.getText().toString();

                Postservice_rating(customer_id, service_id, ratingval, review);
                Toast.makeText(Servicesdetails.this, "Services Rate Successfully", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Servicesdetails.this, MainActivity.class);
                startActivity(intent);
            }
        });

        android.support.v7.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.services);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        service_img = findViewById(R.id.service_img);
        serviceimg2 = findViewById(R.id.serviceimg2);
        serviceimg3 = findViewById(R.id.serviceimg3);
        service_name = findViewById(R.id.service_name);
        service_price = findViewById(R.id.service_price);
        service_matrials = findViewById(R.id.service_matrials);
        service_duration = findViewById(R.id.service_duration);

        String serviceimg = getIntent().getStringExtra("serviceimage");
        String service_img2 = getIntent().getStringExtra("serviceimg2");
        String service_img3 = getIntent().getStringExtra("serviceimg3");
        String servicename = getIntent().getStringExtra("servicename");
        String serviceprice = getIntent().getStringExtra("serviceprice");
        String serviceduration = getIntent().getStringExtra("serviceduration");
        String servicematrials = getIntent().getStringExtra("servicematerils");


        Glide.with(this).load(serviceimg).into(service_img);
        Glide.with(this).load(service_img2).into(serviceimg2);
        Glide.with(this).load(service_img3).into(serviceimg3);
        service_name.setText(servicename);
        service_price.setText(serviceprice);
        service_matrials.setText(servicematrials);
        service_duration.setText(serviceduration);

    }

    private void PostAddcart(String service_id) {
        pDialog = new ProgressDialog(Servicesdetails.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call<Example> call = apiService.Postaddcart(service_id, customer_id);
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                GetValues getValues = new GetValues(Servicesdetails.this);
                String EMAIL = getValues.mEmail();
                if (EMAIL == null) {
                    Intent intent = new Intent(Servicesdetails.this, Login.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                    pDialog.dismiss();
                } else {
                    pDialog.dismiss();
                    Log.d("DATARES", "DATATABLE" + response + call);
                    dailog_sin();
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.e(">> ", t.toString());
                Toast.makeText(Servicesdetails.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }


    private void Postservice_rating(String customer_id, String service_id, Float ratingval, String review) {

        Call<Example> call = apiService.Postservice_rating(customer_id, service_id, ratingval, review);
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                Log.d("DATARES", "DATATABLE" + response + call);
                try {

                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Log.e(">> ", t.toString());
                Toast.makeText(Servicesdetails.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });


    }

    public void PostWishlist1(String service_id) {
        pDialog = new ProgressDialog(Servicesdetails.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        Call<Example> call = apiService.Postwishlistadd(service_id, customer_id);
        call.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, retrofit2.Response<Example> response) {
                GetValues getValues = new GetValues(Servicesdetails.this);
                String EMAIL = getValues.mEmail();
                if (EMAIL == null) {
                    Intent intent = new Intent(Servicesdetails.this, Login.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                    pDialog.dismiss();
                } else {
                    pDialog.dismiss();
                    Log.d("DATARES", "DATATABLE" + response + call);
                    dailog_sin1();
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Toast.makeText(Servicesdetails.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }

    private void dailog_sin1() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.AlertDialogCustomwishlist);
        builder.setTitle("Wish list");
        builder.setMessage("Add to wish list");
        builder.setNegativeButton("LATER", null);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Servicesdetails.this, Wishlist.class);
                startActivity(intent);
            }
        }).create().show();
    }


    private void dailog_sin() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, R.style.AlertDialogCustomCart);
        builder.setTitle("Cart");
        builder.setMessage("Add to cart");
        builder.setNegativeButton("LATER", null);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Servicesdetails.this, AddCart.class);
                startActivity(intent);
            }
        }).create().show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return true;
    }

}


