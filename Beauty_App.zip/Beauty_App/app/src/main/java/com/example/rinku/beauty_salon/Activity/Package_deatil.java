package com.example.rinku.beauty_salon.Activity;

import android.content.Intent;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.MainActivity;
import com.example.rinku.beauty_salon.R;

public class Package_deatil extends AppCompatActivity {
    TextView package_count;
    int mCartItemCount = 0;
    String views="3";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_package_deatil);

        ImageView package_imgs = findViewById(R.id.package_imgs);
        TextView package_title = findViewById(R.id.package_title);
        TextView package_materils = findViewById(R.id.package_materils);
        TextView package_price = findViewById(R.id.package_price);
        TextView package_detail = findViewById(R.id.package_detail);
        //  Button btnbooknow=findViewById (R.id.btnbooknow);

        String Title = getIntent().getStringExtra("Title");
        String Detail = getIntent().getStringExtra("Detail");
        String Materils = getIntent().getStringExtra("Materils");
        String Price = getIntent().getStringExtra("Price");
        String Image = getIntent().getStringExtra("Image");

        Glide.with(this).load(Image).into(package_imgs);
        package_title.setText(Html.fromHtml(Title));
        package_detail.setText(Html.fromHtml(Detail));
        package_materils.setText(Html.fromHtml(Materils));
        package_price.setText(Html.fromHtml(Price));


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.inflateMenu(R.menu.packageview);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        fatchCartItem ();
    }
    protected void onStart() {
        super.onStart ();
        fatchCartItem ();
    }

    private void fatchCartItem() {
        if (views.equals (0)) {
            try {
                mCartItemCount = 0;
                setupBadge (mCartItemCount);
            } catch (Exception ex) {
            }
        } else {
            try {
                mCartItemCount = Integer.parseInt (views);
                setupBadge (mCartItemCount);
            } catch (Exception ex) {
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater ();
        inflater.inflate (R.menu.packageview, menu);
        final MenuItem menuItem = menu.findItem (R.id.package_view);
        View actionView = MenuItemCompat.getActionView (menuItem);
        package_count = (TextView) actionView.findViewById (R.id.package_count);
        setupBadge (mCartItemCount);
        return true;
    }

    public void setupBadge(int upBadge) {
        if (package_count != null) {
            if (this.mCartItemCount == 0) {
                if (package_count.getVisibility () != View.GONE) {
                    package_count.setVisibility (View.GONE);
                }
            } else {
                package_count.setText (String.valueOf (Math.min (this.mCartItemCount, upBadge)));
                if (package_count.getVisibility () != View.VISIBLE) {
                    package_count.setVisibility (View.VISIBLE);
                }
            }
        }
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return super.onOptionsItemSelected(item);
    }
}
