package com.example.rinku.beauty_salon.Activity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rinku.beauty_salon.Adpater.Wishlist_Adapter;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.APIClient;
import com.example.rinku.beauty_salon.Rest.Datum;
import com.example.rinku.beauty_salon.Rest.Example;
import com.example.rinku.beauty_salon.Rest.GetValues;
import com.example.rinku.beauty_salon.Rest.RetroClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class Wishlist extends AppCompatActivity {

    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private static RecyclerView recyclerView;
    String customer_id1;
    private APIClient apiService;
    TextView message;
    ProgressDialog pDialog;
//    SwipeController swipeController = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);

        apiService = RetroClient.getClient().create(APIClient.class);
        GetValues getValues = new GetValues(Wishlist.this);
        SharedPreferences prefs = getSharedPreferences("myPref", MODE_PRIVATE);
        customer_id1 = prefs.getString("CUSTOMERID", getValues.cid());

        message = findViewById(R.id.message);

        android.support.v7.widget.Toolbar toolbar = findViewById(R.id.toolbar_con);
        setTitle(R.string.wishlist);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        recyclerView = (RecyclerView) findViewById(R.id.wish);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());


        Postwish(customer_id1);
    }

    public void Postwish(String customer_id1) {
        pDialog = new ProgressDialog(Wishlist.this);
        pDialog.setMessage("Please wait...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
        message.setVisibility(GONE);
        Call <Example> call = apiService.Postwishlist(customer_id1);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                List <Datum> data = response.body().getData();
                try {

                    if (data == null) {
                        message.setVisibility(VISIBLE);
                        recyclerView.setVisibility(GONE);
                        pDialog.dismiss();
                    } else {
                        pDialog.dismiss();
                        Log.d("DATAMAIN", "DATAonResponse:" + response);
                        message.setVisibility(GONE);
                        adapter = new Wishlist_Adapter(data, Wishlist.this);
                        recyclerView.setAdapter(adapter);
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Log.e(">> ", t.toString());
                Toast.makeText(Wishlist.this, "Connection Error", Toast.LENGTH_SHORT).show();
                pDialog.dismiss();
            }
        });
    }


    public void Postdeletewishlist(String service_id) {
        Call <Example> call = apiService.postdeletewishlist(service_id, customer_id1);
        call.enqueue(new Callback <Example>() {
            @Override
            public void onResponse(Call <Example> call, retrofit2.Response <Example> response) {
                try {


                    Log.d("DATARES", "DATATABLE" + response + call);
                    Postwish(customer_id1);
                } catch (Exception e) {
                }
            }

            @Override
            public void onFailure(Call <Example> call, Throwable t) {
                Toast.makeText(Wishlist.this, "Connection Error", Toast.LENGTH_SHORT).show();
//                pDialog.dismiss();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.text1) ;
        finish();
        return super.onOptionsItemSelected(item);
    }

}
