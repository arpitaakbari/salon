package com.example.rinku.beauty_salon.Adpater;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.rinku.beauty_salon.Activity.Service_Master;
import com.example.rinku.beauty_salon.Activity.Service_Type;
import com.example.rinku.beauty_salon.R;
import com.example.rinku.beauty_salon.Rest.Datum;

import java.util.List;

public class ServicesMaster_Adapter extends RecyclerView.Adapter<ServicesMaster_Adapter.MyViewHolder> {
    private List<Datum> dataSet;
    Context context;
    public ServicesMaster_Adapter(List<Datum> data, Service_Master service) {

        dataSet = data;
        context = service;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textViewtitle;
        ImageView imageViewblog;
        CardView card_view;

        public MyViewHolder(View itemView) {
            super (itemView);
            this.card_view=itemView.findViewById (R.id.card_view);
            this.textViewtitle = (TextView) itemView.findViewById (R.id.trips_title);
            this.imageViewblog = (ImageView) itemView.findViewById (R.id.blog_img);
        }
    }

    @Override
    public ServicesMaster_Adapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.blog_layout, parent, false);
       MyViewHolder myViewHolder=new MyViewHolder (view);
       return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final ServicesMaster_Adapter.MyViewHolder holder, final int listPosition) {

        holder.textViewtitle.setText (dataSet.get (listPosition).getName ());
        Glide.with (context).load (dataSet.get (listPosition).getImage ()).into (holder.imageViewblog);
        holder.card_view.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent (context, Service_Type.class);
                mainIntent.putExtra ("id",dataSet.get (listPosition).getId ());
                context.startActivity (mainIntent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return dataSet.size ();
    }
}
